
import React, { useState, useEffect, useCallback } from 'react';
import { onAuthStateChanged, signOut } from "https://www.gstatic.com/firebasejs/10.8.0/firebase-auth.js";
import { auth } from './services/firebase';
import { User, SiteSettings, OrderStatus, Order, ToastType } from './types';
import { dbService, DEFAULT_SETTINGS } from './services/db';
import Home from './pages/Home';
import Login from './pages/Login';
import GameDetail from './pages/GameDetail';
import Profile from './pages/Profile';
import Orders from './pages/Orders';
import AddMoney from './pages/AddMoney';
import InstantPay from './pages/InstantPay';
import MyCodes from './pages/MyCodes';
import AdminDashboard from './pages/Admin/Dashboard';

const App: React.FC = () => {
    const [user, setUser] = useState<User | null>(null);
    const [loading, setLoading] = useState(true);
    const [currentPage, setCurrentPage] = useState<string>('home');
    const [selectedGameId, setSelectedGameId] = useState<string | null>(null);
    const [tempOrderData, setTempOrderData] = useState<any>(null);
    const [settings, setSettings] = useState<SiteSettings>(DEFAULT_SETTINGS);
    const [isSidebarOpen, setIsSidebarOpen] = useState(false);
    const [redirectPath, setRedirectPath] = useState<{page: string, data?: any} | null>(null);
    const [toast, setToast] = useState<ToastType | null>(null);

    const showToast = useCallback((message: string, type: 'success' | 'error' | 'info' = 'info') => {
        setToast({ message, type });
        setTimeout(() => setToast(null), 3000);
    }, []);

    useEffect(() => {
        dbService.getSettings().then(setSettings);

        const unsubscribe = onAuthStateChanged(auth, async (firebaseUser) => {
            if (firebaseUser) {
                const profile = await dbService.getUserProfile(firebaseUser.uid);
                setUser(profile);
            } else {
                setUser(null);
            }
            setLoading(false);
        });
        return () => unsubscribe();
    }, []);

    const handleLogout = async () => {
        await signOut(auth);
        showToast('Logged out successfully', 'info');
        setCurrentPage('home');
        setIsSidebarOpen(false);
    };

    const navigateTo = (page: string, data?: any) => {
        const restrictedPages = ['profile', 'orders', 'add_money', 'instant_pay', 'my_codes', 'admin'];
        if (!user && restrictedPages.includes(page)) {
            setRedirectPath({ page, data });
            setCurrentPage('login');
            return;
        }

        if (page === 'game_detail') setSelectedGameId(data);
        if (page === 'instant_pay') setTempOrderData(data);
        setCurrentPage(page);
        window.scrollTo(0, 0);
        setIsSidebarOpen(false);
    };

    if (loading) {
        return (
            <div className="min-h-screen flex items-center justify-center bg-white">
                <div className="flex flex-col items-center gap-4">
                    <div className="w-16 h-16 bg-red-600 rounded-3xl flex items-center justify-center shadow-xl pulse-animation">
                        <i className="fa-solid fa-fire text-white text-3xl"></i>
                    </div>
                    <p className="font-bold text-slate-400 text-sm animate-pulse uppercase tracking-[0.2em]">Flame Up Loading...</p>
                </div>
            </div>
        );
    }

    // Banned Screen Component
    const BannedScreen = () => (
        <div className="fixed inset-0 z-[200] bg-slate-900 flex flex-col items-center justify-center p-8 text-center animate-in fade-in duration-500">
            <div className="w-24 h-24 bg-red-600/20 rounded-[2.5rem] flex items-center justify-center mb-8 border border-red-500/30">
                <i className="fa-solid fa-user-slash text-red-500 text-4xl"></i>
            </div>
            <div className="space-y-3 mb-10">
                <h1 className="text-3xl font-black text-white tracking-tighter uppercase">Account Suspended</h1>
                <p className="text-slate-400 text-sm font-medium leading-relaxed max-w-xs">
                    Your account has been restricted for violating our safety guidelines or terms of service.
                </p>
            </div>
            <div className="w-full max-w-xs bg-slate-800/50 border border-white/5 p-6 rounded-3xl space-y-4 mb-8">
                <div className="flex items-center justify-between text-xs">
                    <span className="text-slate-500 font-black uppercase tracking-widest">Support Pin</span>
                    <span className="text-red-500 font-black tracking-widest">{user?.supportPin}</span>
                </div>
                <div className="h-[1px] bg-white/5"></div>
                <p className="text-[10px] text-slate-500 font-bold uppercase tracking-wider">Contact Admin via WhatsApp to appeal</p>
            </div>
            <button 
                onClick={handleLogout}
                className="w-full max-w-xs bg-white text-slate-900 py-5 rounded-2xl font-black text-xs uppercase tracking-widest shadow-2xl active:scale-95 transition-all"
            >
                Logout Session
            </button>
        </div>
    );

    const Header = () => (
        <header className="sticky top-0 z-40 bg-white/90 backdrop-blur-md shadow-sm border-b border-slate-100">
            <div className="max-w-2xl mx-auto flex items-center justify-between px-4 py-3">
                <div className="flex items-center gap-3">
                    <button onClick={() => setIsSidebarOpen(true)} className="p-1 hover:bg-slate-100 rounded-lg transition-colors">
                        <i className="fa-solid fa-bars text-xl text-slate-700"></i>
                    </button>
                    <div onClick={() => navigateTo('home')} className="flex items-center gap-1 cursor-pointer">
                        <div className="bg-red-600 p-1.5 rounded-lg shadow-sm shadow-red-200">
                            <i className="fa-solid fa-fire text-white text-xs"></i>
                        </div>
                        <span className="font-black text-lg tracking-tighter">FLAME<span className="text-red-600">UP</span></span>
                    </div>
                </div>

                <div className="flex items-center gap-2">
                    {user ? (
                        <>
                            <div onClick={() => navigateTo('add_money')} className="bg-red-50 px-3 py-1.5 rounded-full flex items-center gap-2 cursor-pointer hover:bg-red-100 transition-colors border border-red-100">
                                <i className="fa-solid fa-wallet text-red-600 text-[10px]"></i>
                                <span className="text-xs font-black text-red-700">{settings.currencySymbol}{user.balance.toFixed(0)}</span>
                            </div>
                            <div onClick={() => navigateTo('profile')} className="w-9 h-9 rounded-full bg-slate-900 flex items-center justify-center text-white font-black text-sm border-2 border-white shadow-md cursor-pointer overflow-hidden active:scale-95 transition-transform">
                                {(user.username || 'U').charAt(0).toUpperCase()}
                            </div>
                        </>
                    ) : (
                        <button onClick={() => navigateTo('login')} className="bg-red-600 text-white px-5 py-2 rounded-xl text-xs font-black shadow-lg shadow-red-200 hover:bg-red-700 transition-all active:scale-95 uppercase tracking-widest">
                            Login
                        </button>
                    )}
                </div>
            </div>
        </header>
    );

    const Sidebar = () => (
        <div className={`fixed inset-0 z-50 transition-all duration-300 ${isSidebarOpen ? 'opacity-100 pointer-events-auto' : 'opacity-0 pointer-events-none'}`}>
            <div className="absolute inset-0 bg-slate-900/60 backdrop-blur-sm transition-opacity" onClick={() => setIsSidebarOpen(false)}></div>
            <div className={`absolute top-0 left-0 h-full w-80 bg-white shadow-2xl transition-transform duration-500 cubic-bezier transform ${isSidebarOpen ? 'translate-x-0' : '-translate-x-full'}`}>
                <div className="p-8 border-b border-slate-100 bg-slate-50/50">
                    <div className="flex items-center justify-between mb-8">
                        <span className="font-black text-2xl tracking-tighter">FLAME<span className="text-red-600">UP</span></span>
                        <button onClick={() => setIsSidebarOpen(false)} className="w-10 h-10 flex items-center justify-center rounded-xl bg-white border border-slate-200 text-slate-400 hover:text-red-600 transition-all shadow-sm">
                            <i className="fa-solid fa-xmark"></i>
                        </button>
                    </div>
                    {user ? (
                        <div className="flex items-center gap-4 bg-white p-4 rounded-2xl border border-slate-100 shadow-sm">
                            <div className="w-14 h-14 rounded-2xl bg-slate-900 flex items-center justify-center text-white font-black text-2xl shadow-lg">
                                {(user.username || 'U').charAt(0).toUpperCase()}
                            </div>
                            <div className="min-w-0">
                                <h3 className="font-black text-slate-900 leading-tight truncate">@{user.username}</h3>
                                <p className="text-xs text-slate-500 font-bold mt-0.5">{user.phone}</p>
                            </div>
                        </div>
                    ) : (
                        <div className="bg-red-600 p-6 rounded-3xl text-center shadow-xl shadow-red-100">
                            <p className="text-xs text-red-100 font-bold mb-4 uppercase tracking-widest">Welcome to the Arena</p>
                            <button onClick={() => navigateTo('login')} className="w-full bg-white text-red-600 py-3 rounded-xl text-xs font-black uppercase shadow-sm active:scale-95 transition-all">Sign In / Join</button>
                        </div>
                    )}
                </div>
                <div className="p-6 space-y-2">
                    {[
                        { icon: 'fa-house', label: 'Home', page: 'home' },
                        { icon: 'fa-plus-square', label: 'Recharge Wallet', page: 'add_money' },
                        { icon: 'fa-bookmark', label: 'My Orders', page: 'orders' },
                        { icon: 'fa-ticket', label: 'Voucher Codes', page: 'my_codes' },
                        { icon: 'fa-user-circle', label: 'My Profile', page: 'profile' },
                    ].map(item => (
                        <button 
                            key={item.label}
                            onClick={() => navigateTo(item.page)}
                            className={`w-full flex items-center gap-4 px-5 py-4 rounded-2xl transition-all duration-300 ${currentPage === item.page ? 'bg-red-600 text-white shadow-xl shadow-red-100 translate-x-2' : 'text-slate-500 hover:bg-slate-50 hover:text-slate-900'}`}
                        >
                            <i className={`fa-solid ${item.icon} w-6 text-xl`}></i>
                            <span className="font-black text-sm uppercase tracking-widest">{item.label}</span>
                        </button>
                    ))}
                    {user?.isAdmin && (
                        <button 
                            onClick={() => navigateTo('admin')}
                            className="w-full flex items-center gap-4 px-5 py-4 rounded-2xl text-red-600 bg-red-50 mt-6 border border-red-100"
                        >
                            <i className="fa-solid fa-shield-halved w-6 text-xl"></i>
                            <span className="font-black text-sm uppercase tracking-widest">Admin Panel</span>
                        </button>
                    )}
                </div>
                {user && (
                    <div className="absolute bottom-6 left-6 right-6">
                        <button 
                            onClick={handleLogout}
                            className="w-full flex items-center justify-center gap-3 py-5 text-red-600 font-black text-xs uppercase tracking-widest border-2 border-red-50 rounded-2xl hover:bg-red-50 transition-all active:scale-95"
                        >
                            <i className="fa-solid fa-power-off"></i>
                            Logout Session
                        </button>
                    </div>
                )}
            </div>
        </div>
    );

    const BottomNav = () => (
        <nav className="fixed bottom-0 left-0 right-0 z-40 bg-white/80 backdrop-blur-md border-t border-slate-100 flex items-center justify-around py-4 px-2 shadow-[0_-4px_20px_rgba(0,0,0,0.03)] md:hidden h-20">
            {[
                { icon: 'fa-house', label: 'Home', page: 'home' },
                { icon: 'fa-plus-square', label: 'Wallet', page: 'add_money' },
                { icon: 'fa-bookmark', label: 'Orders', page: 'orders' },
                { icon: 'fa-ticket', label: 'Codes', page: 'my_codes' },
                { icon: 'fa-user-circle', label: 'Profile', page: 'profile' },
            ].map(item => (
                <button 
                    key={item.label}
                    onClick={() => navigateTo(item.page)}
                    className={`flex flex-col items-center gap-1.5 transition-all duration-300 ${currentPage === item.page ? 'text-red-600 scale-110' : 'text-slate-400'}`}
                >
                    <i className={`fa-solid ${item.icon} text-xl`}></i>
                    <span className="text-[9px] font-black uppercase tracking-widest">{item.label}</span>
                </button>
            ))}
        </nav>
    );

    const Toast = () => (
        <div className={`fixed top-24 left-1/2 -translate-x-1/2 z-[100] transition-all duration-500 transform ${toast ? 'translate-y-0 opacity-100' : '-translate-y-12 opacity-0 pointer-events-none'}`}>
            <div className={`px-8 py-4 rounded-[2rem] shadow-2xl flex items-center gap-3 border backdrop-blur-xl ${toast?.type === 'success' ? 'bg-green-600 border-green-500 shadow-green-200' : toast?.type === 'error' ? 'bg-red-600 border-red-500 shadow-red-200' : 'bg-slate-900 border-slate-800 shadow-slate-200'} text-white`}>
                <div className="w-8 h-8 rounded-full bg-white/20 flex items-center justify-center">
                    <i className={`fa-solid ${toast?.type === 'success' ? 'fa-check' : toast?.type === 'error' ? 'fa-exclamation' : 'fa-info'} text-xs`}></i>
                </div>
                <span className="text-xs font-black uppercase tracking-widest">{toast?.message}</span>
            </div>
        </div>
    );

    const renderContent = () => {
        switch (currentPage) {
            case 'home': return <Home onSelectGame={(id) => navigateTo('game_detail', id)} />;
            case 'login': return <Login onLogin={(u) => { 
                setUser(u);
                showToast(`Access Granted, ${u.username}!`, 'success');
                if (redirectPath) {
                    navigateTo(redirectPath.page, redirectPath.data);
                    setRedirectPath(null);
                } else {
                    setCurrentPage('home');
                }
            }} showToast={showToast} />;
            case 'game_detail': return <GameDetail user={user} onUpdateUser={setUser} onNavigate={navigateTo} gameId={selectedGameId || ''} onProceedToPay={(data) => navigateTo('instant_pay', data)} showToast={showToast} />;
            case 'profile': return <Profile user={user} onLogout={handleLogout} onUpdateUser={setUser} onNavigate={navigateTo} showToast={showToast} />;
            case 'orders': return <Orders userId={user?.id || ''} onNavigate={navigateTo} showToast={showToast} />;
            case 'add_money': return <AddMoney onNavigate={navigateTo} showToast={showToast} />;
            case 'instant_pay': return <InstantPay orderData={tempOrderData} userId={user?.id || ''} onNavigate={navigateTo} showToast={showToast} />;
            case 'my_codes': return <MyCodes userId={user?.id || ''} showToast={showToast} />;
            case 'admin': return <AdminDashboard onNavigate={navigateTo} showToast={showToast} />;
            default: return <Home onSelectGame={(id) => navigateTo('game_detail', id)} />;
        }
    };

    return (
        <div className="min-h-screen bg-slate-50 selection:bg-red-100 selection:text-red-600 relative">
            {/* Full-screen Ban Interceptor */}
            {user?.ban === true && <BannedScreen />}
            
            <Header />
            <Sidebar />
            <Toast />
            <main className="max-w-2xl mx-auto min-h-screen bg-white md:shadow-[0_0_50px_rgba(0,0,0,0.03)] relative pb-28 md:pb-12">
                {renderContent()}
            </main>
            <BottomNav />
            <a 
                href={settings.fabLink} 
                target="_blank" 
                rel="noopener noreferrer"
                className="fixed bottom-24 right-6 z-50 bg-green-500 text-white w-14 h-14 rounded-full flex items-center justify-center shadow-2xl hover:bg-green-600 transition-all active:scale-90 pulse-animation md:bottom-10"
            >
                <i className="fa-brands fa-whatsapp text-2xl"></i>
            </a>
        </div>
    );
};

export default App;
