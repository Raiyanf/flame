
export enum OrderStatus {
    PENDING = 'Pending',
    COMPLETED = 'Completed',
    CANCELLED = 'Cancelled',
    PROCESSING = 'Processing'
}

export enum GameType {
    UID = 'Uid Top Up',
    VOUCHER = 'Unipin Voucher'
}

export interface User {
    id: string; // Internal UID
    uid: string; // Auth UID (redundant for logic match)
    username: string;
    name: string;
    phone: string;
    email: string;
    balance: number;
    ban: boolean; // true for banned, false for active
    order: number; // Total order count
    spend: number; // Total spent amount
    supportPin: string;
    isAdmin?: boolean;
    password?: string;
    // Legacy mapping support
    totalSpent?: number;
    totalOrders?: number;
}

export interface Game {
    id: string;
    name: string;
    type: GameType;
    description: string;
    image: string;
}

export interface Product {
    id: string;
    gameId: string;
    name: string;
    price: number;
    description?: string;
}

export interface Slider {
    id: string;
    image: string;
    link?: string;
}

export interface PaymentMethod {
    id: string;
    name: string;
    logo?: string;
    qrImage?: string;
    number: string;
    description: string;
}

export interface Order {
    id: string;
    userId: string;
    userName: string;
    gameName: string;
    productName: string;
    price: number;
    quantity: number;
    playerUid?: string;
    paymentMethod: string;
    status: OrderStatus;
    trxId?: string;
    date: string;
    voucherCode?: string;
}

export interface SiteSettings {
    siteName: string;
    siteTitle: string;
    siteDescription: string;
    currencySymbol: string;
    fabLink: string;
    youtubeLink: string;
    marqueeStatus: boolean;
    marqueeText: string;
}

export type ToastType = {
    message: string;
    type: 'success' | 'error' | 'info';
};
