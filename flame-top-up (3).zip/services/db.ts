
import { ref, get, set, update, remove } from "https://www.gstatic.com/firebasejs/10.8.0/firebase-database.js";
import { db } from './firebase';
import { User, Game, Product, Slider, PaymentMethod, Order, SiteSettings, GameType, OrderStatus } from '../types';

export const DEFAULT_SETTINGS: SiteSettings = {
    siteName: 'Flame Top Up',
    siteTitle: 'Best Gaming Top Up Platform',
    siteDescription: 'Fastest and cheapest diamonds and UC top up store in Bangladesh.',
    currencySymbol: '৳',
    fabLink: 'https://chat.whatsapp.com/DQRjguaMBxZAMhhoxGhguE?mode=gi_t',
    youtubeLink: 'https://youtube.com/@raiyanxy?si=BSjc0p1KC9fvmTXL',
    marqueeStatus: true,
    marqueeText: 'Welcome to Flame Top Up! Use code FLAME20 for extra discount. Stay connected!'
};

export const dbService = {
    getSettings: async (): Promise<SiteSettings> => {
        const snapshot = await get(ref(db, 'settings'));
        return snapshot.exists() ? snapshot.val() as SiteSettings : DEFAULT_SETTINGS;
    },

    updateSettings: async (settings: SiteSettings) => {
        await set(ref(db, 'settings'), settings);
    },

    getSliders: async (): Promise<Slider[]> => {
        const snapshot = await get(ref(db, 'sliders'));
        if (snapshot.exists()) {
            return Object.values(snapshot.val()) as Slider[];
        }
        return [];
    },

    addSlider: async (slider: Omit<Slider, 'id'>) => {
        const id = 'sld_' + Date.now();
        await set(ref(db, `sliders/${id}`), { ...slider, id });
    },

    updateSlider: async (id: string, slider: Partial<Slider>) => {
        await update(ref(db, `sliders/${id}`), slider);
    },

    deleteSlider: async (id: string) => {
        await remove(ref(db, `sliders/${id}`));
    },
    
    getUserProfile: async (uid: string): Promise<User | null> => {
        const snapshot = await get(ref(db, `user/${uid}`));
        return snapshot.exists() ? snapshot.val() as User : null;
    },

    findUserByEmail: async (email: string): Promise<User | null> => {
        const snapshot = await get(ref(db, 'user'));
        if (snapshot.exists()) {
            const users = snapshot.val();
            const found = Object.values(users).find((u: any) => u.email.toLowerCase() === email.toLowerCase());
            return found ? (found as User) : null;
        }
        return null;
    },

    isUsernameAvailable: async (username: string): Promise<boolean> => {
        const snapshot = await get(ref(db, 'user'));
        if (snapshot.exists()) {
            const users = snapshot.val();
            const found = Object.values(users).some((u: any) => u.username.toLowerCase() === username.toLowerCase().trim());
            return !found;
        }
        return true;
    },

    isPhoneAvailable: async (phone: string): Promise<boolean> => {
        const snapshot = await get(ref(db, 'user'));
        if (snapshot.exists()) {
            const users = snapshot.val();
            const found = Object.values(users).some((u: any) => u.phone === phone.trim());
            return !found;
        }
        return true;
    },

    createUserProfile: async (uid: string, data: Partial<User>): Promise<User> => {
        const newUser = {
            username: (data.username || '').toLowerCase().trim(),
            phone: (data.phone || '').trim(),
            email: (data.email || '').toLowerCase().trim(),
            password: data.password || '',
            uid: uid,
            balance: 0,
            ban: false, // Changed from 0 to false
            order: 0,
            spend: 0,
            name: (data.username || 'User'), 
            id: uid,
            supportPin: Math.floor(10000 + Math.random() * 90000).toString(),
            isAdmin: false
        };
        await set(ref(db, `user/${uid}`), newUser);
        return newUser as unknown as User;
    },

    updateUserBalance: async (uid: string, newBalance: number): Promise<void> => {
        await update(ref(db, `user/${uid}`), { balance: newBalance });
    },

    updateUserProfile: async (uid: string, updates: Partial<User>): Promise<void> => {
        await update(ref(db, `user/${uid}`), updates);
    },

    getUsers: async (): Promise<User[]> => {
        const snapshot = await get(ref(db, 'user'));
        return snapshot.exists() ? Object.values(snapshot.val()) : [];
    },

    getGames: async (): Promise<Game[]> => {
        const snapshot = await get(ref(db, 'games'));
        if (snapshot.exists()) {
            return Object.values(snapshot.val()) as Game[];
        }
        return [];
    },

    addGame: async (game: Omit<Game, 'id'>) => {
        const gameId = 'g' + Date.now();
        await set(ref(db, `games/${gameId}`), { ...game, id: gameId });
    },

    updateGame: async (gameId: string, game: Partial<Game>) => {
        await update(ref(db, `games/${gameId}`), game);
    },

    deleteGame: async (gameId: string) => {
        await remove(ref(db, `games/${gameId}`));
        // Also remove products of this game
        const snapshot = await get(ref(db, 'products'));
        if (snapshot.exists()) {
            const products = snapshot.val();
            for (const pid in products) {
                if (products[pid].gameId === gameId) {
                    await remove(ref(db, `products/${pid}`));
                }
            }
        }
    },

    getProductsByGame: async (gameId: string): Promise<Product[]> => {
        const snapshot = await get(ref(db, 'products'));
        if (snapshot.exists()) {
            const allProducts = Object.values(snapshot.val()) as Product[];
            return allProducts.filter(p => p.gameId === gameId);
        }
        return [];
    },

    addProduct: async (product: Omit<Product, 'id'>) => {
        const pid = 'p' + Date.now();
        await set(ref(db, `products/${pid}`), { ...product, id: pid });
    },

    deleteProduct: async (id: string) => {
        await remove(ref(db, `products/${id}`));
    },

    getPaymentMethods: () => [
        { id: 'm1', name: 'Bkash', number: '01234567890', description: 'Personal number. Pay carefully.', qrImage: 'https://firebasestorage.googleapis.com/v0/b/demoprobeta3.appspot.com/o/image_url%2Funnamed.webp?alt=media&token=0ed775c0-3519-4fd9-9e73-47f2ca70ff32' },
        { id: 'm2', name: 'Nagad', number: '01987654321', description: 'Nagad Personal', qrImage: 'https://firebasestorage.googleapis.com/v0/b/demoprobeta3.appspot.com/o/image_url%2Funnamed.webp?alt=media&token=0ee63953-8ab3-4561-89b9-a161a3c3f7f4' }
    ],

    createOrder: async (order: Omit<Order, 'id' | 'date' | 'status'> & { status?: OrderStatus }) => {
        const orderId = 'ORD' + Math.floor(100000 + Math.random() * 900000);
        const newOrder: Order = {
            ...order,
            id: orderId,
            date: new Date().toISOString(),
            status: order.status || OrderStatus.PENDING
        };
        
        const updates: any = {};
        updates[`orders/${orderId}`] = newOrder;
        updates[`user_orders/${order.userId}/${orderId}`] = true;
        
        const userRef = ref(db, `user/${order.userId}`);
        const userSnap = await get(userRef);
        if (userSnap.exists()) {
            const userData = userSnap.val();
            updates[`user/${order.userId}/order`] = (userData.order || 0) + 1;
            if (newOrder.status === OrderStatus.COMPLETED) {
                updates[`user/${order.userId}/spend`] = (userData.spend || 0) + order.price;
            }
        }
        await update(ref(db), updates);
        return newOrder;
    },

    getOrders: async (userId?: string): Promise<Order[]> => {
        if (!userId) {
            const snapshot = await get(ref(db, 'orders'));
            return snapshot.exists() ? Object.values(snapshot.val()) : [];
        } else {
            const userOrdersSnapshot = await get(ref(db, `user_orders/${userId}`));
            if (!userOrdersSnapshot.exists()) return [];
            
            const orderIds = Object.keys(userOrdersSnapshot.val());
            const orders: Order[] = [];
            for (const id of orderIds) {
                const orderSnap = await get(ref(db, `orders/${id}`));
                if (orderSnap.exists()) orders.push(orderSnap.val());
            }
            return orders.sort((a, b) => new Date(b.date).getTime() - new Date(a.date).getTime());
        }
    },

    updateOrderStatus: async (orderId: string, status: OrderStatus) => {
        const orderSnap = await get(ref(db, `orders/${orderId}`));
        if (!orderSnap.exists()) return;
        const order = orderSnap.val() as Order;
        const updates: any = {};
        updates[`orders/${orderId}/status`] = status;
        if (status === OrderStatus.COMPLETED && order.status !== OrderStatus.COMPLETED) {
            const userRef = ref(db, `user/${order.userId}`);
            const userSnap = await get(userRef);
            if (userSnap.exists()) {
                updates[`user/${order.userId}/spend`] = (userSnap.val().spend || 0) + order.price;
            }
        }
        await update(ref(db), updates);
    }
};
