
import { initializeApp } from "https://www.gstatic.com/firebasejs/10.8.0/firebase-app.js";
import { getAuth, GoogleAuthProvider, FacebookAuthProvider } from "https://www.gstatic.com/firebasejs/10.8.0/firebase-auth.js";
import { getDatabase } from "https://www.gstatic.com/firebasejs/10.8.0/firebase-database.js";

const firebaseConfig = {
  apiKey: "AIzaSyD0dr-m-m6hiFVECXDVPxMxpqdUWVWPzUQ",
  authDomain: "raiyan-e96b2.firebaseapp.com",
  databaseURL: "https://raiyan-e96b2-default-rtdb.firebaseio.com",
  projectId: "raiyan-e96b2",
  storageBucket: "raiyan-e96b2.firebasestorage.app",
  messagingSenderId: "294718801638",
  appId: "1:294718801638:web:3c21842ff7001b01c01d27",
  measurementId: "G-8H8MCFWBRR"
};

const app = initializeApp(firebaseConfig);
export const auth = getAuth(app);
export const db = getDatabase(app);

// Providers
export const googleProvider = new GoogleAuthProvider();
googleProvider.setCustomParameters({ prompt: 'select_account' });

export const facebookProvider = new FacebookAuthProvider();
