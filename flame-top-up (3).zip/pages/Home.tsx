
import React, { useState, useEffect } from 'react';
import { dbService } from '../services/db';
import { Game, Slider, SiteSettings } from '../types';

interface Props {
    onSelectGame: (id: string) => void;
}

const Home: React.FC<Props> = ({ onSelectGame }) => {
    const [sliders, setSliders] = useState<Slider[]>([]);
    const [currentSlide, setCurrentSlide] = useState(0);
    const [games, setGames] = useState<Game[]>([]);
    const [settings, setSettings] = useState<SiteSettings | null>(null);
    const [isLoading, setIsLoading] = useState(true);

    useEffect(() => {
        const loadHomeData = async () => {
            const [fetchedSliders, fetchedGames, fetchedSettings] = await Promise.all([
                dbService.getSliders(),
                dbService.getGames(),
                dbService.getSettings()
            ]);
            setSliders(fetchedSliders);
            setGames(fetchedGames);
            setSettings(fetchedSettings);
            setIsLoading(false);
        };
        loadHomeData();
    }, []);

    useEffect(() => {
        if (sliders.length <= 1) return;
        const interval = setInterval(() => {
            setCurrentSlide(prev => (prev + 1) % sliders.length);
        }, 4000); 
        return () => clearInterval(interval);
    }, [sliders.length]);

    if (isLoading || !settings) {
        return (
            <div className="p-4 space-y-4 animate-pulse">
                <div className="aspect-video bg-slate-200 rounded-2xl"></div>
                <div className="h-8 bg-slate-200 rounded-xl"></div>
                <div className="grid grid-cols-3 gap-4">
                    {[1,2,3].map(i => <div key={i} className="aspect-square bg-slate-200 rounded-xl"></div>)}
                </div>
            </div>
        );
    }

    return (
        <div className="p-4 space-y-5 slide-up">
            {/* Slider */}
            {sliders.length > 0 && (
                <div className="relative w-full aspect-video rounded-3xl overflow-hidden shadow-2xl bg-slate-100 group">
                    {sliders.map((slider, idx) => (
                        <a 
                            key={slider.id}
                            href={slider.link || '#'}
                            target={slider.link ? "_blank" : "_self"}
                            rel="noopener noreferrer"
                            className={`absolute inset-0 w-full h-full transition-all duration-1000 cubic-bezier transform ${idx === currentSlide ? 'opacity-100 scale-100' : 'opacity-0 scale-110 pointer-events-none'}`}
                        >
                            <img 
                                src={slider.image}
                                className="w-full h-full object-cover"
                                alt="Gaming Slider"
                            />
                            {slider.link && (
                                <div className="absolute inset-0 bg-gradient-to-t from-black/40 to-transparent flex items-end p-6 opacity-0 group-hover:opacity-100 transition-opacity">
                                    <div className="bg-white/20 backdrop-blur-md px-4 py-2 rounded-full text-white text-[10px] font-black uppercase tracking-widest border border-white/20">
                                        Visit Promotion <i className="fa-solid fa-arrow-right ml-2"></i>
                                    </div>
                                </div>
                            )}
                        </a>
                    ))}
                    {sliders.length > 1 && (
                        <div className="absolute bottom-4 left-1/2 -translate-x-1/2 flex gap-2 z-10">
                            {sliders.map((_, idx) => (
                                <button 
                                    key={idx} 
                                    onClick={() => setCurrentSlide(idx)}
                                    className={`h-1.5 rounded-full transition-all duration-500 ${idx === currentSlide ? 'bg-red-600 w-6' : 'bg-white/40 w-1.5 hover:bg-white/60'}`}
                                ></button>
                            ))}
                        </div>
                    )}
                </div>
            )}

            {/* Notice Marquee */}
            {settings.marqueeStatus && (
                <div className="bg-red-600 text-white text-[10px] py-3 rounded-2xl marquee-container shadow-xl shadow-red-100 border border-red-500 flex items-center overflow-hidden">
                    <div className="shrink-0 bg-red-700 px-4 z-10 relative h-full flex items-center">
                        <i className="fa-solid fa-bullhorn animate-pulse"></i>
                    </div>
                    <span className="marquee-content px-4 font-black tracking-[0.1em] uppercase">{settings.marqueeText}</span>
                </div>
            )}

            {/* Game Shop Section */}
            <section className="space-y-5 pt-2">
                <div className="flex items-center justify-between px-1">
                    <div className="flex items-center gap-3">
                        <div className="w-1 h-6 bg-red-600 rounded-full"></div>
                        <h2 className="text-xl font-black text-slate-900 tracking-tight">Active Shop</h2>
                    </div>
                    <span className="text-[10px] font-black text-red-600 bg-red-50 px-3 py-1 rounded-full uppercase tracking-widest border border-red-100">Live Inventory</span>
                </div>
                
                <div className="grid grid-cols-3 gap-4">
                    {games.map(game => (
                        <div 
                            key={game.id} 
                            onClick={() => onSelectGame(game.id)}
                            className="flex flex-col gap-2.5 group cursor-pointer"
                        >
                            <div className="aspect-square rounded-2xl overflow-hidden shadow-lg group-hover:shadow-red-100/50 transition-all border border-slate-100 bg-slate-50 relative">
                                <img src={game.image} className="w-full h-full object-cover group-hover:scale-110 transition-transform duration-700" alt={game.name} />
                                <div className="absolute inset-0 bg-black/0 group-hover:bg-black/10 transition-colors"></div>
                            </div>
                            <h3 className="text-[10px] font-black text-center text-slate-800 line-clamp-1 uppercase tracking-tighter">{game.name}</h3>
                        </div>
                    ))}
                </div>
            </section>
        </div>
    );
};

export default Home;
