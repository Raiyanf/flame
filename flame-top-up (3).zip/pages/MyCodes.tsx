
import React, { useState, useEffect } from 'react';
import { dbService } from '../services/db';
import { OrderStatus, Order } from '../types';

interface Props {
    userId: string;
    showToast: (message: string, type?: 'success' | 'error' | 'info') => void;
}

const MyCodes: React.FC<Props> = ({ userId, showToast }) => {
    const [ordersWithCodes, setOrdersWithCodes] = useState<Order[]>([]);

    useEffect(() => {
        dbService.getOrders(userId).then(orders => {
            const filtered = orders.filter(o => o.status === OrderStatus.COMPLETED && o.voucherCode);
            setOrdersWithCodes(filtered);
        });
    }, [userId]);

    return (
        <div className="p-4 space-y-6 slide-up min-h-screen">
            <div className="flex items-center justify-between">
                <h1 className="text-xl font-black text-slate-900">Voucher Codes</h1>
                <a href="https://shop.garena.my/app" target="_blank" rel="noopener noreferrer" className="bg-red-600 text-white px-4 py-2 rounded-xl text-xs font-bold shadow-lg shadow-red-100">Redeem Site</a>
            </div>

            {ordersWithCodes.length === 0 ? (
                <div className="py-20 flex flex-col items-center justify-center text-center space-y-4">
                    <div className="w-20 h-20 bg-slate-50 rounded-full flex items-center justify-center text-slate-300">
                        <i className="fa-solid fa-ticket text-4xl"></i>
                    </div>
                    <div>
                        <h3 className="font-bold text-slate-900">No Codes Found</h3>
                        <p className="text-xs text-slate-500">Buy Unipin or Garena Vouchers to see codes here.</p>
                    </div>
                </div>
            ) : (
                <div className="space-y-4">
                    {ordersWithCodes.map(order => (
                        <div key={order.id} className="bg-white p-5 rounded-3xl border border-slate-100 shadow-sm space-y-4">
                            <div className="flex justify-between items-center">
                                <div className="flex items-center gap-3">
                                    <div className="w-10 h-10 bg-orange-50 text-orange-600 rounded-2xl flex items-center justify-center">
                                        <i className="fa-solid fa-ticket"></i>
                                    </div>
                                    <div>
                                        <h3 className="text-sm font-black text-slate-900">{order.gameName}</h3>
                                        <p className="text-[10px] text-slate-500 font-bold">{order.productName}</p>
                                    </div>
                                </div>
                                <span className="text-[10px] text-slate-400 font-bold">{new Date(order.date).toLocaleDateString()}</span>
                            </div>

                            <div className="bg-slate-900 p-4 rounded-2xl relative overflow-hidden group">
                                <div className="absolute top-0 right-0 w-16 h-16 bg-red-600/10 rounded-full -translate-y-1/2 translate-x-1/2"></div>
                                <p className="text-[8px] font-black text-slate-500 uppercase tracking-[0.2em] mb-1">Voucher Key</p>
                                <div className="flex items-center justify-between">
                                    <p className="text-xl font-black text-white tracking-widest">{order.voucherCode}</p>
                                    <button 
                                        onClick={() => {
                                            navigator.clipboard.writeText(order.voucherCode!);
                                            showToast('Code copied to clipboard!', 'success');
                                        }}
                                        className="bg-white/10 hover:bg-white/20 text-white w-10 h-10 rounded-xl flex items-center justify-center transition-all active:scale-90"
                                    >
                                        <i className="fa-solid fa-copy"></i>
                                    </button>
                                </div>
                            </div>
                        </div>
                    ))}
                </div>
            )}
        </div>
    );
};

export default MyCodes;
