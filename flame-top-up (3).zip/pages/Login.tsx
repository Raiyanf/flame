
import React, { useState, useEffect } from 'react';
import { 
    signInWithEmailAndPassword, 
    createUserWithEmailAndPassword, 
    sendEmailVerification,
    sendPasswordResetEmail,
    setPersistence,
    browserLocalPersistence,
    browserSessionPersistence,
    fetchSignInMethodsForEmail
} from "https://www.gstatic.com/firebasejs/10.8.0/firebase-auth.js";
import { auth } from '../services/firebase';
import { dbService } from '../services/db';
import { User } from '../types';

interface Props {
    onLogin: (user: User) => void;
    showToast: (msg: string, type?: 'success' | 'error' | 'info') => void;
}

const Login: React.FC<Props> = ({ onLogin, showToast }) => {
    const [mode, setMode] = useState<'login' | 'signup'>('login');
    const [email, setEmail] = useState('');
    const [password, setPassword] = useState('');
    const [showPassword, setShowPassword] = useState(false);
    const [username, setUsername] = useState('');
    const [phone, setPhone] = useState('');
    const [isLoading, setIsLoading] = useState(false);
    const [rememberMe, setRememberMe] = useState(true);
    
    // Step-based registration state
    const [registrationStep, setRegistrationStep] = useState<'initial' | 'verifying'>('initial');

    useEffect(() => {
        const savedEmail = localStorage.getItem('REMEMBERED_EMAIL');
        if (savedEmail) {
            setEmail(savedEmail);
            setRememberMe(true);
        }
    }, []);

    const getFriendlyErrorMessage = (error: any) => {
        const code = error.code;
        switch (code) {
            case 'auth/invalid-email': return "Email format is incorrect.";
            case 'auth/user-not-found': return "Account not found.";
            case 'auth/wrong-password': return "Incorrect password.";
            case 'auth/invalid-credential': return "Invalid login credentials.";
            case 'auth/email-already-in-use': return "Email is already registered.";
            case 'auth/weak-password': return "Password must be 6+ characters.";
            case 'auth/too-many-requests': return "Too many attempts. Try later.";
            default: return error.message;
        }
    };

    const handleForgotPassword = async () => {
        if (!email.trim() || !email.includes('@')) {
            return showToast('Please enter your email address first.', 'error');
        }
        
        setIsLoading(true);
        try {
            // Check if user exists first to provide better feedback
            const user = await dbService.findUserByEmail(email.trim());
            if (!user) {
                showToast('No account found with this email.', 'error');
                return;
            }

            await sendPasswordResetEmail(auth, email.trim());
            showToast('Password reset link sent to your email!', 'success');
        } catch (error: any) {
            showToast(getFriendlyErrorMessage(error), 'error');
        } finally {
            setIsLoading(false);
        }
    };

    const handleLogin = async () => {
        setIsLoading(true);
        try {
            // Handle persistence based on "Remember Me"
            await setPersistence(auth, rememberMe ? browserLocalPersistence : browserSessionPersistence);
            
            const credential = await signInWithEmailAndPassword(auth, email.trim(), password);
            
            if (!credential.user.emailVerified) {
                setIsLoading(false);
                setRegistrationStep('verifying');
                showToast('Please verify your email first.', 'info');
                return;
            }

            const profile = await dbService.getUserProfile(credential.user.uid);
            if (!profile) {
                showToast('Account profile not found.', 'error');
                return;
            }

            if (rememberMe) {
                localStorage.setItem('REMEMBERED_EMAIL', email);
            } else {
                localStorage.removeItem('REMEMBERED_EMAIL');
            }

            onLogin(profile);
        } catch (error: any) {
            showToast(getFriendlyErrorMessage(error), 'error');
        } finally {
            setIsLoading(false);
        }
    };

    const handleInitialSignup = async () => {
        if (!username.trim() || username.length < 3) return showToast('Username must be 3+ chars.', 'error');
        if (!phone.trim() || phone.length < 10) return showToast('Enter valid phone number.', 'error');
        
        setIsLoading(true);
        try {
            const [isUserAvail, isPhoneAvail] = await Promise.all([
                dbService.isUsernameAvailable(username),
                dbService.isPhoneAvailable(phone)
            ]);

            if (!isUserAvail) {
                setIsLoading(false);
                return showToast('Username is already taken!', 'error');
            }
            if (!isPhoneAvail) {
                setIsLoading(false);
                return showToast('Phone number already registered!', 'error');
            }

            const credential = await createUserWithEmailAndPassword(auth, email.trim(), password);
            
            await dbService.createUserProfile(credential.user.uid, {
                username: username.trim().toLowerCase(),
                phone: phone.trim(),
                email: email.trim().toLowerCase(),
                password: password, 
            });

            await sendEmailVerification(credential.user);
            showToast('Profile created! Verification email sent.', 'success');
            setRegistrationStep('verifying');
        } catch (error: any) {
            showToast(getFriendlyErrorMessage(error), 'error');
        } finally {
            setIsLoading(false);
        }
    };

    const handleSubmit = async (e: React.FormEvent) => {
        e.preventDefault();
        if (!email.trim() || !email.includes('@')) return showToast('Please enter a valid email.', 'error');
        if (password.length < 6) return showToast('Password must be at least 6 characters.', 'error');
        
        if (mode === 'login') {
            await handleLogin();
        } else {
            if (registrationStep === 'verifying') {
                await checkVerificationAndComplete();
            } else {
                await handleInitialSignup();
            }
        }
    };

    const checkVerificationAndComplete = async () => {
        setIsLoading(true);
        try {
            await auth.currentUser?.reload();
            const firebaseUser = auth.currentUser;

            if (firebaseUser && firebaseUser.emailVerified) {
                const profile = await dbService.getUserProfile(firebaseUser.uid);
                if (profile) {
                    if (rememberMe) localStorage.setItem('REMEMBERED_EMAIL', email);
                    onLogin(profile);
                } else {
                    showToast('Profile setup incomplete.', 'error');
                }
            } else {
                showToast('Please verify your email first.', 'info');
            }
        } catch (err: any) {
            showToast('Verification check failed.', 'error');
        } finally {
            setIsLoading(false);
        }
    };

    return (
        <div className="min-h-screen flex flex-col bg-white">
            <div className="flex flex-col items-center justify-center pt-12 pb-8 gap-4 px-6">
                <div className="w-20 h-20 bg-red-600 rounded-[2.5rem] flex items-center justify-center shadow-2xl shadow-red-100 rotate-12 transition-transform hover:rotate-0 duration-500">
                    <i className="fa-solid fa-fire text-white text-4xl -rotate-12 hover:rotate-0 transition-transform duration-500"></i>
                </div>
                <div className="text-center space-y-1">
                    <h1 className="text-3xl font-black text-slate-900 tracking-tighter">FLAME<span className="text-red-600">UP</span></h1>
                    <p className="text-xs font-bold text-slate-400 uppercase tracking-[0.2em]">
                        {registrationStep === 'verifying' ? 'Verification Required' : mode === 'login' ? 'Welcome Back' : 'Join the Arena'}
                    </p>
                </div>
            </div>

            <div className="flex-1 px-8 pb-12">
                {registrationStep === 'initial' && (
                    <div className="flex bg-slate-50 p-1 rounded-2xl mb-8 border border-slate-100">
                        <button onClick={() => setMode('login')} className={`flex-1 py-3.5 rounded-xl font-black text-xs uppercase tracking-widest transition-all ${mode === 'login' ? 'bg-white text-red-600 shadow-md border border-red-50' : 'text-slate-400'}`}>Sign In</button>
                        <button onClick={() => setMode('signup')} className={`flex-1 py-3.5 rounded-xl font-black text-xs uppercase tracking-widest transition-all ${mode === 'signup' ? 'bg-white text-red-600 shadow-md border border-red-50' : 'text-slate-400'}`}>Sign Up</button>
                    </div>
                )}

                <form onSubmit={handleSubmit} className="space-y-5">
                    {registrationStep === 'verifying' ? (
                        <div className="text-center space-y-6 py-4 animate-in fade-in duration-500">
                            <div className="w-16 h-16 bg-blue-50 text-blue-600 rounded-full flex items-center justify-center mx-auto text-2xl bounce-animation">
                                <i className="fa-solid fa-envelope-open-text"></i>
                            </div>
                            <div className="space-y-2">
                                <p className="text-sm font-bold text-slate-700">Check your inbox:</p>
                                <p className="text-xs font-black text-red-600">{email}</p>
                            </div>
                            <p className="text-[10px] text-slate-400 font-medium leading-relaxed">
                                Once verified, click the button below to complete setup.
                            </p>
                            <button 
                                type="submit"
                                disabled={isLoading}
                                className="w-full bg-green-600 text-white py-5 rounded-[1.8rem] font-black text-lg shadow-xl shadow-green-100 active:scale-95 transition-all flex items-center justify-center gap-3"
                            >
                                {isLoading ? <i className="fa-solid fa-circle-notch fa-spin"></i> : <i className="fa-solid fa-circle-check"></i>}
                                Complete Registration
                            </button>
                            <button 
                                type="button" 
                                onClick={() => setRegistrationStep('initial')}
                                className="text-[10px] font-black text-slate-400 uppercase tracking-widest"
                            >
                                Use different account
                            </button>
                        </div>
                    ) : (
                        <>
                            {mode === 'signup' && (
                                <div className="grid grid-cols-1 gap-5 animate-in slide-in-from-left duration-300">
                                    <div className="space-y-1.5">
                                        <div className="relative group">
                                            <i className="fa-solid fa-at absolute left-4 top-1/2 -translate-y-1/2 text-slate-300 group-focus-within:text-red-500 transition-colors"></i>
                                            <input 
                                                type="text" 
                                                required 
                                                value={username} 
                                                onChange={e => setUsername(e.target.value.toLowerCase().replace(/[^a-z0-9_]/g, ''))} 
                                                className="w-full bg-slate-50 border border-slate-100 rounded-2xl pl-12 pr-4 py-4 text-sm font-bold focus:bg-white focus:ring-2 focus:ring-red-600 outline-none transition-all placeholder:text-slate-300" 
                                                placeholder="Pick a username" 
                                            />
                                        </div>
                                    </div>
                                    <div className="space-y-1.5">
                                        <div className="relative group">
                                            <i className="fa-solid fa-phone absolute left-4 top-1/2 -translate-y-1/2 text-slate-300 group-focus-within:text-red-500 transition-colors"></i>
                                            <input 
                                                type="tel" 
                                                required 
                                                value={phone} 
                                                onChange={e => setPhone(e.target.value.replace(/\D/g, ''))} 
                                                className="w-full bg-slate-50 border border-slate-100 rounded-2xl pl-12 pr-4 py-4 text-sm font-bold focus:bg-white focus:ring-2 focus:ring-red-600 outline-none transition-all placeholder:text-slate-300" 
                                                placeholder="Mobile Number" 
                                            />
                                        </div>
                                    </div>
                                </div>
                            )}

                            <div className="space-y-1.5">
                                <div className="relative group">
                                    <i className="fa-solid fa-envelope absolute left-4 top-1/2 -translate-y-1/2 text-slate-300 group-focus-within:text-red-500 transition-colors"></i>
                                    <input 
                                        type="email" 
                                        required 
                                        value={email} 
                                        onChange={e => setEmail(e.target.value)} 
                                        className="w-full bg-slate-50 border border-slate-100 rounded-2xl pl-12 pr-4 py-4 text-sm font-bold focus:bg-white focus:ring-2 focus:ring-red-600 outline-none transition-all placeholder:text-slate-300" 
                                        placeholder="Email Address" 
                                    />
                                </div>
                            </div>

                            <div className="space-y-1.5">
                                <div className="relative group">
                                    <i className="fa-solid fa-lock absolute left-4 top-1/2 -translate-y-1/2 text-slate-300 group-focus-within:text-red-500 transition-colors"></i>
                                    <input 
                                        type={showPassword ? 'text' : 'password'} 
                                        required 
                                        value={password} 
                                        onChange={e => setPassword(e.target.value)} 
                                        className="w-full bg-slate-50 border border-slate-100 rounded-2xl pl-12 pr-12 py-4 text-sm font-bold focus:bg-white focus:ring-2 focus:ring-red-600 outline-none transition-all placeholder:text-slate-300" 
                                        placeholder="Security Password" 
                                    />
                                    <button type="button" onClick={() => setShowPassword(!showPassword)} className="absolute right-4 top-1/2 -translate-y-1/2 text-slate-300 hover:text-red-500 transition-colors">
                                        <i className={`fa-solid ${showPassword ? 'fa-eye-slash' : 'fa-eye'}`}></i>
                                    </button>
                                </div>
                                {mode === 'login' && (
                                    <div className="flex justify-end px-1">
                                        <button 
                                            type="button" 
                                            onClick={handleForgotPassword}
                                            className="text-[10px] font-black text-red-600 uppercase tracking-widest hover:underline"
                                        >
                                            Forgot Password?
                                        </button>
                                    </div>
                                )}
                            </div>

                            {mode === 'login' && (
                                <div className="flex items-center gap-3 px-2 py-2">
                                    <label className="relative flex items-center cursor-pointer">
                                        <input 
                                            type="checkbox" 
                                            className="sr-only peer" 
                                            checked={rememberMe} 
                                            onChange={() => setRememberMe(!rememberMe)} 
                                        />
                                        <div className="w-10 h-5 bg-slate-200 rounded-full peer peer-checked:bg-red-600 transition-all after:content-[''] after:absolute after:top-[2px] after:left-[2px] after:bg-white after:rounded-full after:h-4 after:w-4 after:transition-all peer-checked:after:translate-x-5"></div>
                                        <span className="ml-3 text-[10px] font-black text-slate-500 uppercase tracking-widest">Remind Me</span>
                                    </label>
                                </div>
                            )}

                            <button 
                                type="submit" 
                                disabled={isLoading} 
                                className="w-full bg-red-600 text-white py-5 rounded-[1.8rem] font-black text-lg shadow-2xl shadow-red-200 hover:bg-red-700 active:scale-[0.98] transition-all flex items-center justify-center gap-3 disabled:opacity-50 mt-6"
                            >
                                {isLoading ? (
                                    <i className="fa-solid fa-circle-notch fa-spin text-2xl"></i>
                                ) : (
                                    mode === 'login' ? 'Sign In Account' : 'Create Profile'
                                )}
                            </button>
                        </>
                    )}
                </form>
            </div>
        </div>
    );
};

export default Login;
