
import React, { useState, useEffect } from 'react';
import { dbService } from '../services/db';
import { OrderStatus, Order } from '../types';

interface Props {
    userId: string;
    onNavigate: (page: string) => void;
    showToast: (message: string, type?: 'success' | 'error' | 'info') => void;
}

const Orders: React.FC<Props> = ({ userId, onNavigate, showToast }) => {
    const [orders, setOrders] = useState<Order[]>([]);
    const [expandedOrderId, setExpandedOrderId] = useState<string | null>(null);

    useEffect(() => {
        dbService.getOrders(userId).then(setOrders);
    }, [userId]);

    const getStatusDisplay = (status: OrderStatus) => {
        switch (status) {
            case OrderStatus.COMPLETED: 
                return { text: 'COMPLETED', classes: 'bg-green-100 text-green-700' };
            case OrderStatus.CANCELLED: 
                return { text: 'CANCELLED', classes: 'bg-red-100 text-red-700' };
            case OrderStatus.PENDING: 
            case OrderStatus.PROCESSING:
            default: 
                return { text: 'PROGRESS', classes: 'bg-orange-100 text-orange-700' };
        }
    };

    return (
        <div className="p-4 space-y-6 slide-up min-h-screen">
            <div className="flex items-center justify-between">
                <h1 className="text-xl font-black text-slate-900">My Orders</h1>
                <span className="bg-slate-100 text-slate-500 text-xs px-2 py-1 rounded-lg font-bold">{orders.length} Total</span>
            </div>

            {orders.length === 0 ? (
                <div className="py-20 flex flex-col items-center justify-center text-center space-y-4">
                    <div className="w-20 h-20 bg-slate-50 rounded-full flex items-center justify-center text-slate-300">
                        <i className="fa-solid fa-cart-shopping text-4xl"></i>
                    </div>
                    <div>
                        <h3 className="font-bold text-slate-900">No Orders Yet</h3>
                        <p className="text-xs text-slate-500">Your order history will appear here.</p>
                    </div>
                    <button onClick={() => onNavigate('home')} className="bg-red-600 text-white px-6 py-2 rounded-xl text-sm font-bold shadow-lg shadow-red-100">Browse Shop</button>
                </div>
            ) : (
                <div className="space-y-4">
                    {orders.map(order => {
                        const statusUI = getStatusDisplay(order.status);
                        const isCompleted = order.status === OrderStatus.COMPLETED;
                        
                        return (
                            <div 
                                key={order.id} 
                                onClick={() => setExpandedOrderId(expandedOrderId === order.id ? null : order.id)}
                                className="bg-white rounded-2xl border border-slate-100 shadow-sm overflow-hidden transition-all active:scale-[0.99]"
                            >
                                <div className="p-4 flex items-center gap-4">
                                    <div className="w-12 h-12 bg-slate-50 rounded-xl flex items-center justify-center text-red-600 shrink-0">
                                        <i className="fa-solid fa-gamepad text-xl"></i>
                                    </div>
                                    <div className="flex-1 min-w-0">
                                        <div className="flex justify-between items-start">
                                            <h3 className="font-bold text-slate-900 truncate">{order.gameName}</h3>
                                            <span className={`text-[10px] font-black px-2 py-0.5 rounded uppercase tracking-wider ${statusUI.classes}`}>
                                                {statusUI.text}
                                            </span>
                                        </div>
                                        <p className="text-xs text-slate-500 font-medium">{order.productName}</p>
                                        <div className="flex items-center justify-between mt-1">
                                            <span className={`text-sm font-black transition-colors ${isCompleted ? 'text-green-600' : 'text-red-600'}`}>
                                                ৳{order.price.toFixed(2)}
                                            </span>
                                            <span className="text-[10px] text-slate-400">{new Date(order.date).toLocaleDateString()}</span>
                                        </div>
                                    </div>
                                </div>

                                {expandedOrderId === order.id && (
                                    <div className="px-4 pb-4 pt-2 border-t border-slate-50 bg-slate-50/50 space-y-4 slide-up">
                                        <div className="grid grid-cols-2 gap-4">
                                            <div className="space-y-0.5">
                                                <p className="text-[10px] font-bold text-slate-400 uppercase">Order ID</p>
                                                <p className="text-xs font-bold text-slate-700">#{order.id}</p>
                                            </div>
                                            <div className="space-y-0.5">
                                                <p className="text-[10px] font-bold text-slate-400 uppercase">UID / ID</p>
                                                <p className="text-xs font-bold text-slate-700">{order.playerUid || 'N/A'}</p>
                                            </div>
                                            <div className="space-y-0.5">
                                                <p className="text-[10px] font-bold text-slate-400 uppercase">Payment</p>
                                                <p className="text-xs font-bold text-slate-700">{order.paymentMethod}</p>
                                            </div>
                                            <div className="space-y-0.5">
                                                <p className="text-[10px] font-bold text-slate-400 uppercase">TrxID</p>
                                                <p className="text-xs font-bold text-slate-700 truncate">{order.trxId || 'N/A'}</p>
                                            </div>
                                        </div>

                                        <div className="flex items-center justify-between px-2 pt-2 relative">
                                            <div className="absolute top-1/2 left-4 right-4 h-0.5 bg-slate-200 -translate-y-1/2 z-0"></div>
                                            {[
                                                { label: 'Placed', icon: 'fa-check', active: true, color: 'bg-red-600' },
                                                { 
                                                    label: 'Progress', 
                                                    icon: 'fa-spinner', 
                                                    active: order.status === OrderStatus.PROCESSING || order.status === OrderStatus.COMPLETED,
                                                    color: 'bg-orange-500',
                                                    anim: order.status === OrderStatus.PROCESSING ? 'fa-spin' : ''
                                                },
                                                { label: 'Completed', icon: 'fa-star', active: order.status === OrderStatus.COMPLETED, color: 'bg-green-600' }
                                            ].map((step, idx) => (
                                                <div key={idx} className="flex flex-col items-center gap-1 z-10">
                                                    <div className={`w-6 h-6 rounded-full flex items-center justify-center text-[10px] transition-all duration-300 ${step.active ? `${step.color} text-white shadow-lg` : 'bg-white text-slate-300 border border-slate-200'}`}>
                                                        <i className={`fa-solid ${step.icon} ${step.anim || ''}`}></i>
                                                    </div>
                                                    <span className={`text-[8px] font-black uppercase tracking-tight ${step.active ? 'text-slate-900' : 'text-slate-300'}`}>
                                                        {step.label}
                                                    </span>
                                                </div>
                                            ))}
                                        </div>
                                        
                                        {order.status === OrderStatus.COMPLETED && order.voucherCode && (
                                            <div className="bg-red-50 p-3 rounded-xl border border-red-100 flex items-center justify-between">
                                                <div>
                                                    <p className="text-[10px] font-bold text-red-400 uppercase mb-1">Redeem Code</p>
                                                    <p className="text-sm font-black text-red-600">{order.voucherCode}</p>
                                                </div>
                                                <button 
                                                    onClick={(e) => {
                                                        e.stopPropagation();
                                                        navigator.clipboard.writeText(order.voucherCode!);
                                                        showToast('Voucher code copied!', 'success');
                                                    }}
                                                    className="bg-red-600 text-white px-3 py-1.5 rounded-lg text-xs font-bold"
                                                >
                                                    Copy
                                                </button>
                                            </div>
                                        )}
                                    </div>
                                )}
                            </div>
                        );
                    })}
                </div>
            )}
        </div>
    );
};

export default Orders;
