
import React, { useState, useEffect } from 'react';
import { dbService } from '../services/db';
import { Game, Product, GameType, User, OrderStatus } from '../types';

interface Props {
    gameId: string;
    user: User | null;
    onNavigate: (page: string, data?: any) => void;
    onProceedToPay: (data: any) => void;
    // Updated to handle both direct user updates and state dispatchers
    onUpdateUser?: (user: any) => void;
    // Added showToast property
    showToast: (message: string, type?: 'success' | 'error' | 'info') => void;
}

const GameDetail: React.FC<Props> = ({ gameId, user, onNavigate, onProceedToPay, onUpdateUser, showToast }) => {
    // FIX: Use state and useEffect for async data fetching from dbService
    const [game, setGame] = useState<Game | null>(null);
    const [products, setProducts] = useState<Product[]>([]);
    const [relatedProducts, setRelatedProducts] = useState<Game[]>([]);
    const [loading, setLoading] = useState(true);
    
    const [selectedProduct, setSelectedProduct] = useState<Product | null>(null);
    const [quantity, setQuantity] = useState(1);
    const [playerUid, setPlayerUid] = useState('');
    const [paymentMode, setPaymentMode] = useState<'wallet' | 'instant'>('instant');
    const [isSubmitting, setIsSubmitting] = useState(false);
    const [showSuccessModal, setShowSuccessModal] = useState(false);

    // FIX: Load game details, products, and related games asynchronously
    useEffect(() => {
        const loadGameData = async () => {
            setLoading(true);
            try {
                const [allGames, gameProducts] = await Promise.all([
                    dbService.getGames(),
                    dbService.getProductsByGame(gameId)
                ]);
                const foundGame = allGames.find(g => g.id === gameId);
                setGame(foundGame || null);
                setProducts(gameProducts);
                setRelatedProducts(allGames.filter(g => g.id !== gameId).slice(0, 6));
            } catch (error) {
                console.error("Failed to load game data:", error);
                showToast("Failed to load recharge details.", "error");
            } finally {
                setLoading(false);
            }
        };
        loadGameData();
    }, [gameId]);

    if (loading) return (
        <div className="flex flex-col items-center justify-center py-20 gap-4">
            <i className="fa-solid fa-circle-notch fa-spin text-red-600 text-2xl"></i>
            <p className="text-xs font-bold text-slate-400 animate-pulse uppercase tracking-widest">Loading Game Details...</p>
        </div>
    );

    if (!game) return <div className="p-8 text-center font-black text-slate-400 uppercase tracking-widest">Game not found</div>;

    const totalPrice = selectedProduct ? selectedProduct.price * quantity : 0;
    const userBalance = user?.balance || 0;
    const isBalanceSufficient = userBalance >= totalPrice;

    const handleBuy = async () => {
        // Specific Validation
        if (!selectedProduct) {
            return showToast('Please select a recharge package first!', 'error');
        }
        if (game.type === GameType.UID && !playerUid) {
            return showToast(`Please enter your ${game.name} Player ID!`, 'error');
        }
        
        const orderInfo = {
            game,
            product: selectedProduct,
            quantity,
            playerUid,
            paymentMode,
            totalPrice: totalPrice
        };

        if (!user) {
            // Store order intent and go to login
            onNavigate('login', { from: 'game_detail', orderInfo });
            return;
        }
        
        if (paymentMode === 'wallet') {
            if (!isBalanceSufficient) {
                return showToast(`Insufficient Balance! You need ৳${(totalPrice - userBalance).toFixed(2)} more.`, 'error');
            }

            // Wallet Deduction Logic
            setIsSubmitting(true);
            try {
                const newBalance = userBalance - totalPrice;
                
                // 1. Create the order as COMPLETED (Wallet deduction is instant)
                // This will trigger the increment logic in dbService for spend and order count
                await dbService.createOrder({
                    userId: user.id,
                    userName: user.name,
                    gameName: game.name,
                    productName: selectedProduct.name,
                    price: totalPrice,
                    quantity: quantity,
                    playerUid: playerUid,
                    paymentMethod: 'Wallet',
                    status: OrderStatus.COMPLETED
                });

                // 2. Update Balance in Firebase
                await dbService.updateUserBalance(user.id, newBalance);

                // 3. Update local user state in App.tsx
                // We increment local stats too to avoid waiting for re-fetch
                if (onUpdateUser) {
                    onUpdateUser({ 
                        ...user, 
                        balance: newBalance,
                        order: (user.order || 0) + 1,
                        spend: (user.spend || 0) + totalPrice
                    });
                }

                // 4. Show the Success Popup
                setShowSuccessModal(true);
            } catch (error) {
                showToast('Order failed. Please check your internet connection.', 'error');
            } finally {
                setIsSubmitting(false);
            }
        } else {
            // Instant Pay Flow (manual verification)
            onProceedToPay(orderInfo);
        }
    };

    const handleUidChange = (e: React.ChangeEvent<HTMLInputElement>) => {
        // STRICTLY only allow numbers - any other character is removed immediately
        const value = e.target.value.replace(/\D/g, '');
        setPlayerUid(value);
    };

    return (
        <div className="pb-10 slide-up">
            {/* Success Popup Modal */}
            {showSuccessModal && (
                <div className="fixed inset-0 z-[100] flex items-center justify-center p-6 bg-slate-900/80 backdrop-blur-md animate-in fade-in duration-300">
                    <div className="bg-white w-full max-w-sm rounded-[2.5rem] p-8 shadow-2xl slide-up text-center space-y-6">
                        <div className="w-20 h-20 bg-green-100 text-green-600 rounded-full flex items-center justify-center text-3xl mx-auto bounce-animation">
                            <i className="fa-solid fa-check-double"></i>
                        </div>
                        <div className="space-y-2">
                            <h3 className="text-2xl font-black text-slate-900">Order Successful!</h3>
                            <p className="text-sm text-slate-500 font-medium">Your {selectedProduct?.name} is being processed.</p>
                        </div>
                        <div className="bg-slate-50 rounded-2xl p-4 divide-y divide-slate-200">
                            <div className="flex justify-between py-2 text-xs">
                                <span className="font-bold text-slate-400 uppercase">Paid via Wallet</span>
                                <span className="font-black text-red-600">৳{totalPrice.toFixed(2)}</span>
                            </div>
                            <div className="flex justify-between py-2 text-xs">
                                <span className="font-bold text-slate-400 uppercase">Remaining Balance</span>
                                <span className="font-black text-green-600">৳{(user?.balance || 0).toFixed(2)}</span>
                            </div>
                        </div>
                        <button 
                            onClick={() => onNavigate('orders')}
                            className="w-full bg-slate-900 text-white py-4 rounded-2xl font-black shadow-xl"
                        >
                            View Order History
                        </button>
                        <button 
                            onClick={() => setShowSuccessModal(false)}
                            className="w-full text-slate-400 text-xs font-bold"
                        >
                            Close
                        </button>
                    </div>
                </div>
            )}

            {/* Banner */}
            <div className="relative h-48 bg-slate-900 overflow-hidden">
                <img src={game.image} className="w-full h-full object-cover opacity-50 blur-sm" alt="" />
                <div className="absolute inset-0 flex items-center p-6 gap-6 bg-gradient-to-t from-slate-900 to-transparent">
                    <img src={game.image} className="w-24 h-24 rounded-2xl shadow-2xl border-2 border-white/20" alt="" />
                    <div className="text-white space-y-1">
                        <h1 className="text-2xl font-black tracking-tight">{game.name}</h1>
                        <p className="text-xs text-slate-300 font-medium">{game.type}</p>
                    </div>
                </div>
            </div>

            <div className="p-4 space-y-8 mt-2">
                <section className="space-y-4">
                    <div className="flex items-center gap-2">
                        <span className="w-7 h-7 bg-red-600 text-white rounded-full flex items-center justify-center font-bold text-sm">1</span>
                        <h2 className="font-bold text-slate-900">Select Package</h2>
                    </div>
                    <div className="grid grid-cols-2 gap-3">
                        {products.map(p => (
                            <button
                                key={p.id}
                                onClick={() => setSelectedProduct(p)}
                                className={`p-4 rounded-xl border-2 text-left transition-all ${selectedProduct?.id === p.id ? 'border-red-600 bg-red-50 ring-4 ring-red-100' : 'border-slate-100 hover:border-slate-300'}`}
                            >
                                <div className="flex justify-between items-start mb-1">
                                    <span className="text-xs font-bold text-slate-900">{p.name}</span>
                                    {selectedProduct?.id === p.id && <i className="fa-solid fa-circle-check text-red-600"></i>}
                                </div>
                                <span className="text-sm font-black text-red-600">৳{p.price}</span>
                            </button>
                        ))}
                    </div>
                </section>

                {game.type === GameType.UID && (
                    <section className="space-y-4">
                        <div className="flex items-center gap-2">
                            <span className="w-7 h-7 bg-red-600 text-white rounded-full flex items-center justify-center font-bold text-sm">2</span>
                            <h2 className="font-bold text-slate-900">Player Details</h2>
                        </div>
                        <div className="bg-slate-50 p-4 rounded-2xl border border-slate-100">
                            <label className="text-[10px] font-bold text-slate-400 uppercase tracking-widest mb-1.5 block">Player UID (Numbers Only)</label>
                            <input 
                                type="text" 
                                inputMode="numeric"
                                value={playerUid}
                                onChange={handleUidChange}
                                placeholder="Enter Numeric UID"
                                className="w-full bg-white border border-slate-200 rounded-xl px-4 py-3 text-sm font-bold focus:ring-2 focus:ring-red-600 focus:outline-none"
                            />
                        </div>
                    </section>
                )}

                <section className="space-y-4">
                    <div className="flex items-center gap-2">
                        <span className="w-7 h-7 bg-red-600 text-white rounded-full flex items-center justify-center font-bold text-sm">{game.type === GameType.UID ? '3' : '2'}</span>
                        <h2 className="font-bold text-slate-900">Payment Option</h2>
                    </div>
                    <div className="grid grid-cols-2 gap-3">
                        <button 
                            onClick={() => setPaymentMode('wallet')}
                            className={`p-4 rounded-2xl border-2 transition-all text-center flex flex-col items-center justify-center ${paymentMode === 'wallet' ? 'border-red-600 bg-red-50' : 'border-slate-100'}`}
                        >
                            <i className="fa-solid fa-wallet text-2xl text-red-600 mb-2"></i>
                            <p className="text-xs font-bold">Wallet Pay</p>
                            <p className={`text-[10px] font-black mt-1 transition-colors ${isBalanceSufficient ? 'text-green-600' : 'text-red-600'}`}>
                                Balance: ৳{userBalance.toFixed(2)}
                            </p>
                        </button>
                        <button 
                            onClick={() => setPaymentMode('instant')}
                            className={`p-4 rounded-2xl border-2 transition-all text-center flex flex-col items-center justify-center ${paymentMode === 'instant' ? 'border-red-600 bg-red-50' : 'border-slate-100'}`}
                        >
                            <i className="fa-solid fa-bolt text-2xl text-orange-500 mb-2"></i>
                            <p className="text-xs font-bold">Instant Pay</p>
                            <p className="text-[10px] font-bold text-slate-400 mt-1">Manual Pay</p>
                        </button>
                    </div>
                </section>

                <section className="flex items-center justify-between bg-slate-50 p-4 rounded-2xl">
                    <span className="font-bold text-slate-700">Quantity</span>
                    <div className="flex items-center gap-4 bg-white px-3 py-1.5 rounded-full shadow-sm border border-slate-200">
                        <button onClick={() => setQuantity(q => Math.max(1, q-1))} className="w-8 h-8 flex items-center justify-center text-slate-400 hover:text-red-600"><i className="fa-solid fa-minus"></i></button>
                        <span className="font-black text-lg w-6 text-center">{quantity}</span>
                        <button onClick={() => setQuantity(q => q+1)} className="w-8 h-8 flex items-center justify-center text-slate-400 hover:text-red-600"><i className="fa-solid fa-plus"></i></button>
                    </div>
                </section>

                <button 
                    onClick={handleBuy}
                    disabled={isSubmitting}
                    className="w-full bg-red-600 text-white py-4 rounded-2xl font-black text-lg shadow-xl shadow-red-200 hover:bg-red-700 active:scale-[0.98] transition-all flex items-center justify-center gap-3 disabled:opacity-50"
                >
                    {isSubmitting ? (
                        <i className="fa-solid fa-circle-notch fa-spin"></i>
                    ) : (
                        `Buy Now • ৳${totalPrice.toFixed(2)}`
                    )}
                </button>

                <section className="space-y-4 pt-4">
                    <h2 className="font-bold text-slate-900 border-b pb-2 text-sm">Rules & Conditions</h2>
                    <p className="text-xs text-slate-500 leading-relaxed">
                        {game.description}. Order completion time usually takes 5-30 minutes. Please ensure the player UID is correct. No refunds are available for incorrect player information.
                    </p>
                </section>

                <section className="space-y-4">
                    <h2 className="font-bold text-slate-900 text-sm">Recommended Games</h2>
                    <div className="flex gap-4 overflow-x-auto pb-4 hide-scrollbar">
                        {relatedProducts.map(rp => (
                            <div key={rp.id} onClick={() => onNavigate('game_detail', rp.id)} className="shrink-0 w-24 text-center space-y-2 cursor-pointer">
                                <img src={rp.image} className="w-24 h-24 rounded-xl object-cover shadow-sm" alt="" />
                                <p className="text-[10px] font-bold text-slate-700 truncate">{rp.name}</p>
                            </div>
                        ))}
                    </div>
                </section>
            </div>
        </div>
    );
};

export default GameDetail;
