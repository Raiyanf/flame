
import React, { useState, useEffect } from 'react';
import { dbService } from '../services/db';
import { SiteSettings } from '../types';

interface Props {
    onNavigate: (page: string, data?: any) => void;
    showToast: (message: string, type?: 'success' | 'error' | 'info') => void;
}

const AddMoney: React.FC<Props> = ({ onNavigate, showToast }) => {
    const [amount, setAmount] = useState('');
    // FIX: Handled async settings fetching with state and useEffect
    const [settings, setSettings] = useState<SiteSettings | null>(null);
    const [loading, setLoading] = useState(true);

    useEffect(() => {
        const fetchSettings = async () => {
            try {
                const data = await dbService.getSettings();
                setSettings(data);
            } catch (error) {
                console.error("Error loading settings:", error);
            } finally {
                setLoading(false);
            }
        };
        fetchSettings();
    }, []);

    const handleProceed = () => {
        const val = parseFloat(amount);
        if (!val || val < 10) return showToast('Minimum recharge amount is ৳10', 'error');
        onNavigate('instant_pay', { totalPrice: val, game: { name: 'Wallet Recharge' }, product: { name: `Recharge ৳${val}` }, quantity: 1 });
    };

    if (loading || !settings) {
        return (
            <div className="p-4 space-y-4 animate-pulse">
                <div className="h-8 bg-slate-200 rounded-xl w-48"></div>
                <div className="bg-white p-6 rounded-[2rem] border border-slate-100 shadow-xl space-y-6">
                    <div className="h-20 bg-slate-100 rounded-2xl"></div>
                    <div className="grid grid-cols-4 gap-2">
                        {[1,2,3,4].map(i => <div key={i} className="h-10 bg-slate-100 rounded-xl"></div>)}
                    </div>
                    <div className="h-14 bg-slate-100 rounded-2xl"></div>
                </div>
            </div>
        );
    }

    return (
        <div className="p-4 space-y-6 slide-up">
            <h1 className="text-xl font-black text-slate-900 px-1">Add Money to Wallet</h1>
            
            <section className="bg-white p-6 rounded-[2rem] border border-slate-100 shadow-xl shadow-slate-200/50 space-y-6">
                <div className="space-y-2">
                    <label className="text-[10px] font-black text-slate-400 uppercase tracking-widest px-2">Enter Recharge Amount</label>
                    <div className="relative">
                        <span className="absolute left-5 top-1/2 -translate-y-1/2 text-2xl font-black text-slate-300">৳</span>
                        <input 
                            type="number"
                            value={amount}
                            onChange={e => setAmount(e.target.value)}
                            className="w-full bg-slate-50 border border-slate-100 rounded-2xl pl-12 pr-4 py-5 text-2xl font-black focus:bg-white focus:ring-4 focus:ring-red-100 outline-none transition-all"
                            placeholder="0.00"
                        />
                    </div>
                </div>

                <div className="grid grid-cols-4 gap-2">
                    {[100, 200, 500, 1000].map(val => (
                        <button key={val} onClick={() => setAmount(val.toString())} className="py-2 bg-slate-100 rounded-xl text-xs font-bold text-slate-600 hover:bg-red-50 hover:text-red-600 transition-colors">৳{val}</button>
                    ))}
                </div>

                <button 
                    onClick={handleProceed}
                    className="w-full bg-red-600 text-white py-5 rounded-2xl font-black text-lg shadow-xl shadow-red-200 hover:bg-red-700 active:scale-[0.98] transition-all flex items-center justify-center gap-3"
                >
                    Proceed to Payment
                    <i className="fa-solid fa-arrow-right text-sm"></i>
                </button>
            </section>

            <section className="space-y-4">
                <div className="flex items-center gap-3 px-1">
                    <div className="w-10 h-10 rounded-2xl bg-orange-100 text-orange-600 flex items-center justify-center">
                        <i className="fa-brands fa-youtube text-lg"></i>
                    </div>
                    <h2 className="font-black text-slate-900">How to add money?</h2>
                </div>
                
                <div className="relative aspect-video rounded-[2rem] overflow-hidden shadow-lg border border-slate-100 group cursor-pointer">
                    {/* Safe YouTube thumbnail handling */}
                    <img 
                        src={`https://img.youtube.com/vi/${settings.youtubeLink?.includes('v=') ? settings.youtubeLink.split('v=')[1].split('&')[0] : 'default'}/maxresdefault.jpg`} 
                        className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-700" 
                        alt="Video" 
                    />
                    <div className="absolute inset-0 bg-black/40 flex items-center justify-center">
                        <div className="w-16 h-16 bg-red-600 rounded-full flex items-center justify-center text-white shadow-2xl group-hover:scale-110 transition-all pulse-animation">
                            <i className="fa-solid fa-play text-2xl ml-1"></i>
                        </div>
                    </div>
                    <a href={settings.youtubeLink} target="_blank" rel="noopener noreferrer" className="absolute inset-0"></a>
                </div>
            </section>

            <div className="bg-blue-50 p-5 rounded-2xl border border-blue-100 flex gap-4">
                <i className="fa-solid fa-circle-info text-blue-500 text-xl mt-1"></i>
                <div className="space-y-1">
                    <p className="text-xs font-bold text-blue-900 leading-snug">Important Note:</p>
                    <p className="text-[10px] text-blue-700/70 font-medium leading-relaxed">
                        Recharges are usually added instantly after verification. In rare cases, it might take up to 30 minutes. If balance is not added within an hour, contact support with your Transaction ID.
                    </p>
                </div>
            </div>
        </div>
    );
};

export default AddMoney;
