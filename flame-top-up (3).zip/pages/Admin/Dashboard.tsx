
import React, { useState, useEffect } from 'react';
import { dbService } from '../../services/db';
import { OrderStatus, GameType, Game, Product, Order, User, Slider, SiteSettings } from '../../types';

interface Props {
    onNavigate: (page: string, data?: any) => void;
    showToast: (message: string, type?: 'success' | 'error' | 'info') => void;
}

const AdminDashboard: React.FC<Props> = ({ onNavigate, showToast }) => {
    // Tab Management
    const [activeTab, setActiveTab] = useState<'hub' | 'users' | 'sliders' | 'orders' | 'settings' | 'shop' | 'notice'>('hub');
    
    // Global Data State
    const [orders, setOrders] = useState<Order[]>([]);
    const [users, setUsers] = useState<User[]>([]);
    const [games, setGames] = useState<Game[]>([]);
    const [sliders, setSliders] = useState<Slider[]>([]);
    const [settings, setSettings] = useState<SiteSettings | null>(null);
    
    // UI State
    const [selectedUser, setSelectedUser] = useState<User | null>(null);
    const [isUserModalOpen, setIsUserModalOpen] = useState(false);
    const [userSearchTerm, setUserSearchTerm] = useState('');
    const [orderSearch, setOrderSearch] = useState('');

    // Shop/Stall State
    const [viewingGameProducts, setViewingGameProducts] = useState<Game | null>(null);
    const [gameProducts, setGameProducts] = useState<Product[]>([]);
    const [showGameForm, setShowGameForm] = useState(false);
    const [showProductForm, setShowProductForm] = useState(false);
    const [editingGame, setEditingGame] = useState<Game | null>(null);
    const [stallForm, setStallForm] = useState({ name: '', image: '', type: GameType.UID, description: '' });
    const [newProduct, setNewProduct] = useState({ name: '', price: '' });

    // Slider State
    const [showSliderForm, setShowSliderForm] = useState(false);
    const [newSlider, setNewSlider] = useState({ image: '', link: '' });

    const loadData = async () => {
        try {
            const [fetchedOrders, fetchedUsers, fetchedGames, fetchedSliders, fetchedSettings] = await Promise.all([
                dbService.getOrders(),
                dbService.getUsers(),
                dbService.getGames(),
                dbService.getSliders(),
                dbService.getSettings()
            ]);
            setOrders(fetchedOrders);
            setUsers(fetchedUsers);
            setGames(fetchedGames);
            setSliders(fetchedSliders);
            setSettings(fetchedSettings);
        } catch (e) {
            console.error("Critical: Data fetch failed", e);
            showToast("Failed to connect to server", "error");
        }
    };

    useEffect(() => {
        loadData();
    }, []);

    // --- SHARED ACTIONS ---
    const handleUpdateStatus = async (orderId: string, status: OrderStatus) => {
        try {
            await dbService.updateOrderStatus(orderId, status);
            showToast(`Order updated to ${status}`, 'success');
            await loadData();
        } catch (e) {
            showToast('Failed to update status', 'error');
        }
    };

    const handleUpdateUser = async (userId: string, updates: Partial<User>) => {
        try {
            await dbService.updateUserProfile(userId, updates);
            showToast('User updated!', 'success');
            await loadData();
        } catch (e) {
            showToast('Failed to update user', 'error');
        }
    };

    // --- SLIDER ACTIONS ---
    const handleAddSlider = async () => {
        if (!newSlider.image) return showToast('Image URL is required', 'error');
        await dbService.addSlider(newSlider);
        setShowSliderForm(false);
        setNewSlider({ image: '', link: '' });
        showToast('Slider Added', 'success');
        await loadData();
    };

    const handleDeleteSlider = async (id: string) => {
        if (!confirm('Are you sure you want to delete this slide?')) return;
        try {
            await dbService.deleteSlider(id);
            showToast('Slider deleted successfully', 'info');
            await loadData();
        } catch (err) {
            showToast('Failed to delete slider', 'error');
        }
    };

    // --- SHOP ACTIONS ---
    const handleSaveStall = async () => {
        if (!stallForm.name || !stallForm.image) return showToast('Name and Image are required', 'error');
        try {
            if (editingGame) {
                await dbService.updateGame(editingGame.id, stallForm);
                showToast('Stall changes saved!', 'success');
            } else {
                await dbService.addGame(stallForm);
                showToast('New stall created!', 'success');
            }
            setShowGameForm(false);
            setEditingGame(null);
            setStallForm({ name: '', image: '', type: GameType.UID, description: '' });
            await loadData();
        } catch (err) {
            showToast('Failed to save stall', 'error');
        }
    };

    const handleDeleteGame = async (id: string) => {
        if (!confirm('Warning: This will delete this stall and all its products forever. Continue?')) return;
        try {
            await dbService.deleteGame(id);
            setGames(prev => prev.filter(g => g.id !== id));
            setShowGameForm(false);
            setEditingGame(null);
            setViewingGameProducts(null);
            showToast('Stall removed from inventory', 'info');
            await loadData();
        } catch (err) {
            showToast('Failed to delete stall', 'error');
        }
    };

    const handleAddProduct = async () => {
        if (!viewingGameProducts) return;
        const price = parseFloat(newProduct.price);
        if (!newProduct.name || isNaN(price)) return showToast('Name and Price are required', 'error');
        
        await dbService.addProduct({
            gameId: viewingGameProducts.id,
            name: newProduct.name,
            price: price
        });
        const updated = await dbService.getProductsByGame(viewingGameProducts.id);
        setGameProducts(updated);
        setShowProductForm(false);
        setNewProduct({ name: '', price: '' });
        showToast('Product package added!', 'success');
    };

    const handleDeleteProduct = async (id: string) => {
        if (!confirm('Remove this product?')) return;
        await dbService.deleteProduct(id);
        setGameProducts(prev => prev.filter(p => p.id !== id));
        showToast('Product package removed', 'info');
    };

    const openGameProducts = async (game: Game) => {
        setViewingGameProducts(game);
        const products = await dbService.getProductsByGame(game.id);
        setGameProducts(products);
    };

    // --- NAVIGATION ---
    const resetShopView = () => {
        setViewingGameProducts(null);
        setShowGameForm(false);
        setEditingGame(null);
    };

    return (
        <div className="p-4 space-y-6 min-h-screen bg-slate-50 pb-20">
            {/* User Details Modal */}
            {isUserModalOpen && selectedUser && (
                <div className="fixed inset-0 z-[110] flex items-center justify-center p-4 bg-slate-900/80 backdrop-blur-md">
                    <div className="bg-white w-full max-w-lg rounded-[3rem] p-8 shadow-2xl relative slide-up">
                        <div className="flex justify-between items-center mb-8">
                            <h2 className="text-2xl font-black text-slate-900">User Control</h2>
                            <button onClick={() => setIsUserModalOpen(false)} className="w-12 h-12 bg-slate-50 rounded-2xl flex items-center justify-center"><i className="fa-solid fa-xmark"></i></button>
                        </div>
                        <div className="space-y-6">
                             <div className="flex items-center gap-4 bg-slate-50 p-4 rounded-2xl">
                                <div className={`w-16 h-16 ${selectedUser.ban ? 'bg-red-500' : 'bg-rose-500'} text-white rounded-2xl flex items-center justify-center font-black text-2xl`}>{selectedUser.username.charAt(0).toUpperCase()}</div>
                                <div><p className="font-black">@{selectedUser.username}</p><p className="text-xs text-slate-400 font-bold">{selectedUser.phone}</p></div>
                             </div>
                             <div className="space-y-2">
                                <label className="text-[10px] font-black text-slate-400 uppercase">Modify Balance (৳)</label>
                                <div className="flex gap-2">
                                    <input type="number" id="balanceInput" defaultValue={selectedUser.balance} className="flex-1 bg-slate-50 border p-4 rounded-2xl font-black outline-none focus:ring-2 focus:ring-rose-500" />
                                    <button onClick={() => handleUpdateUser(selectedUser.id, { balance: parseFloat((document.getElementById('balanceInput') as HTMLInputElement).value) })} className="bg-slate-900 text-white px-8 rounded-2xl font-black text-xs uppercase">Update</button>
                                </div>
                             </div>
                             <button onClick={() => handleUpdateUser(selectedUser.id, { ban: !selectedUser.ban })} className={`w-full py-4 rounded-2xl font-black text-xs uppercase ${selectedUser.ban ? 'bg-green-600 text-white' : 'bg-red-600 text-white'}`}>
                                {selectedUser.ban ? 'Unlock Account' : 'Suspend Account'}
                             </button>
                        </div>
                    </div>
                </div>
            )}

            {/* Admin Header */}
            <div className="flex items-center justify-between bg-slate-900 p-6 rounded-[2rem] text-white shadow-2xl">
                <div className="space-y-1">
                    <h1 className="text-2xl font-black tracking-tight">Admin Console</h1>
                    <p className="text-[10px] font-bold text-slate-400 uppercase tracking-widest">Flame Management Hub</p>
                </div>
                {activeTab !== 'hub' && (
                    <button onClick={() => { setActiveTab('hub'); resetShopView(); }} className="bg-white/10 hover:bg-white/20 px-4 py-2 rounded-xl flex items-center gap-2 transition-colors font-black text-[10px] uppercase tracking-widest">
                        <i className="fa-solid fa-house"></i> Hub
                    </button>
                )}
            </div>

            {/* MAIN CONTENT AREA */}
            <div className="pb-10">
                {activeTab === 'hub' && (
                    <div className="grid grid-cols-1 gap-4 slide-up">
                        {[
                            { id: 'users', label: 'User', icon: 'fa-users', color: 'bg-rose-500', shadow: 'shadow-rose-100', desc: 'Member Controls' },
                            { id: 'sliders', label: 'Slides', icon: 'fa-images', color: 'bg-blue-500', shadow: 'shadow-blue-100', desc: 'Slider Content' },
                            { id: 'notice', label: 'Home Notice', icon: 'fa-bullhorn', color: 'bg-amber-500', shadow: 'shadow-amber-100', desc: 'Alert Marquee' },
                            { id: 'orders', label: 'All', icon: 'fa-list-check', color: 'bg-emerald-500', shadow: 'shadow-emerald-100', desc: 'Order Stream' },
                            { id: 'shop', label: 'Shop', icon: 'fa-store', color: 'bg-indigo-500', shadow: 'shadow-indigo-100', desc: 'Game Inventory' },
                            { id: 'settings', label: 'Settings', icon: 'fa-gear', color: 'bg-slate-600', shadow: 'shadow-slate-100', desc: 'Site Config' }
                        ].map((item, idx) => (
                            <button key={idx} onClick={() => setActiveTab(item.id as any)} className={`${item.color} p-6 rounded-[2.5rem] text-white flex items-center justify-between shadow-xl ${item.shadow} active:scale-[0.97] transition-all group overflow-hidden relative`}>
                                <div className="absolute top-0 right-0 w-32 h-32 bg-white/10 rounded-full translate-x-12 -translate-y-12 group-hover:scale-110 transition-transform"></div>
                                <div className="flex items-center gap-6 z-10">
                                    <div className="w-16 h-16 bg-white/20 rounded-2xl flex items-center justify-center backdrop-blur-md">
                                        <i className={`fa-solid ${item.icon} text-2xl`}></i>
                                    </div>
                                    <div className="text-left">
                                        <h3 className="text-xl font-black tracking-tight">{item.label}</h3>
                                        <p className="text-[10px] font-bold opacity-70 uppercase tracking-widest">{item.desc}</p>
                                    </div>
                                </div>
                                <div className="w-10 h-10 bg-black/10 rounded-full flex items-center justify-center z-10">
                                    <i className="fa-solid fa-chevron-right text-xs"></i>
                                </div>
                            </button>
                        ))}
                    </div>
                )}

                {activeTab === 'users' && (
                    <div className="space-y-4 slide-up">
                        <div className="flex flex-col gap-4">
                            <h2 className="font-black text-slate-900 px-1">User Management</h2>
                            <div className="relative">
                                <i className="fa-solid fa-magnifying-glass absolute left-4 top-1/2 -translate-y-1/2 text-slate-400"></i>
                                <input type="text" placeholder="Search users..." value={userSearchTerm} onChange={(e) => setUserSearchTerm(e.target.value)} className="w-full bg-white border border-slate-200 rounded-2xl pl-12 pr-4 py-4 text-sm font-bold shadow-sm outline-none" />
                            </div>
                        </div>
                        <div className="grid grid-cols-1 gap-3">
                            {users.filter(u => u.username.toLowerCase().includes(userSearchTerm.toLowerCase()) || u.phone.includes(userSearchTerm)).map(user => (
                                <div key={user.id} onClick={() => { setSelectedUser(user); setIsUserModalOpen(true); }} className="bg-white p-5 rounded-3xl border border-slate-100 shadow-sm flex items-center justify-between group cursor-pointer active:scale-[0.98]">
                                    <div className="flex items-center gap-4">
                                        <div className={`w-14 h-14 rounded-2xl flex items-center justify-center text-white font-black text-xl ${user.ban ? 'bg-red-500' : 'bg-rose-500'}`}>
                                            {user.username.charAt(0).toUpperCase()}
                                        </div>
                                        <div>
                                            <h3 className="font-black text-slate-900 truncate">@{user.username}</h3>
                                            <p className="text-[10px] text-slate-400 font-bold uppercase">{user.phone}</p>
                                        </div>
                                    </div>
                                    <div className="text-right">
                                        <p className="text-sm font-black text-rose-600">৳{user.balance.toFixed(0)}</p>
                                        <p className="text-[8px] font-bold text-slate-300 uppercase">{user.order} Orders</p>
                                    </div>
                                </div>
                            ))}
                        </div>
                    </div>
                )}

                {activeTab === 'sliders' && (
                    <div className="space-y-6 slide-up pb-10">
                        <div className="flex items-center justify-between px-1">
                            <h2 className="font-black text-slate-900">Slider Content</h2>
                            <button onClick={() => setShowSliderForm(true)} className="bg-blue-600 text-white px-4 py-2 rounded-xl text-[10px] font-black uppercase tracking-widest shadow-lg">Add Slide</button>
                        </div>
                        {showSliderForm && (
                            <div className="bg-white p-6 rounded-3xl border border-slate-100 shadow-xl space-y-4">
                                <input type="text" placeholder="Image URL" value={newSlider.image} onChange={e => setNewSlider({...newSlider, image: e.target.value})} className="w-full bg-slate-50 border p-4 rounded-2xl text-sm font-bold" />
                                <input type="text" placeholder="Link (Optional)" value={newSlider.link} onChange={e => setNewSlider({...newSlider, link: e.target.value})} className="w-full bg-slate-50 border p-4 rounded-2xl text-sm font-bold" />
                                <div className="flex gap-2">
                                    <button onClick={handleAddSlider} className="flex-1 bg-blue-600 text-white py-4 rounded-2xl font-black text-xs uppercase">Save Slide</button>
                                    <button onClick={() => setShowSliderForm(false)} className="px-6 bg-slate-100 text-slate-500 rounded-2xl font-black text-xs uppercase">Cancel</button>
                                </div>
                            </div>
                        )}
                        <div className="grid grid-cols-1 gap-4">
                            {sliders.map(slider => (
                                <div key={slider.id} className="bg-white p-4 rounded-3xl border border-slate-100 shadow-sm relative group">
                                    <img src={slider.image} className="w-full aspect-video rounded-2xl object-cover mb-3" />
                                    <button 
                                        onClick={(e) => { e.stopPropagation(); handleDeleteSlider(slider.id); }} 
                                        className="absolute top-6 right-6 w-10 h-10 bg-red-600 text-white rounded-xl shadow-lg flex items-center justify-center hover:scale-110 transition-transform cursor-pointer"
                                    >
                                        <i className="fa-solid fa-trash-can"></i>
                                    </button>
                                    <p className="text-[10px] font-bold text-slate-400 truncate px-2">{slider.link || 'No Link Attached'}</p>
                                </div>
                            ))}
                        </div>
                    </div>
                )}

                {activeTab === 'shop' && (
                    <div className="space-y-6 slide-up pb-10">
                        {viewingGameProducts ? (
                            <div className="space-y-6 slide-up">
                                <div className="flex items-center justify-between px-1">
                                    <button onClick={resetShopView} className="flex items-center gap-2 text-[10px] font-black uppercase text-indigo-600 bg-indigo-50 px-3 py-2 rounded-xl border border-indigo-100 shadow-sm">
                                        <i className="fa-solid fa-arrow-left"></i> All Stalls
                                    </button>
                                    <button onClick={() => setShowProductForm(true)} className="bg-indigo-600 text-white px-4 py-2 rounded-xl text-[10px] font-black uppercase tracking-widest shadow-lg">
                                        New Package
                                    </button>
                                </div>
                                <div className="bg-white p-6 rounded-[2.5rem] border border-slate-100 shadow-sm flex items-center gap-6">
                                    <img src={viewingGameProducts.image} className="w-20 h-20 rounded-2xl object-cover border" />
                                    <div>
                                        <h2 className="text-xl font-black text-slate-900">{viewingGameProducts.name}</h2>
                                        <p className="text-xs font-bold text-slate-400 uppercase tracking-widest">{viewingGameProducts.type}</p>
                                    </div>
                                </div>
                                {showProductForm && (
                                    <div className="bg-white p-6 rounded-3xl border border-indigo-100 shadow-xl space-y-4 animate-in zoom-in-95">
                                        <h3 className="text-xs font-black uppercase tracking-widest text-slate-900">Add Item to {viewingGameProducts.name}</h3>
                                        <input type="text" placeholder="Package Name (e.g. 100 Diamonds)" value={newProduct.name} onChange={e => setNewProduct({...newProduct, name: e.target.value})} className="w-full bg-slate-50 border p-4 rounded-2xl text-sm font-bold outline-none" />
                                        <input type="number" placeholder="Price (৳)" value={newProduct.price} onChange={e => setNewProduct({...newProduct, price: e.target.value})} className="w-full bg-slate-50 border p-4 rounded-2xl text-sm font-bold outline-none" />
                                        <div className="flex gap-2">
                                            <button onClick={handleAddProduct} className="flex-1 bg-indigo-600 text-white py-4 rounded-2xl font-black text-xs uppercase">Save Item</button>
                                            <button onClick={() => setShowProductForm(false)} className="px-6 bg-slate-100 text-slate-500 rounded-2xl font-black text-xs uppercase">Cancel</button>
                                        </div>
                                    </div>
                                )}
                                <div className="space-y-3">
                                    {gameProducts.map(p => (
                                        <div key={p.id} className="bg-white p-4 rounded-2xl border border-slate-100 shadow-sm flex items-center justify-between group">
                                            <div>
                                                <p className="text-sm font-black text-slate-800">{p.name}</p>
                                                <p className="text-xs font-black text-indigo-600">৳{p.price}</p>
                                            </div>
                                            <button onClick={() => handleDeleteProduct(p.id)} className="w-10 h-10 bg-red-50 text-red-300 hover:bg-red-500 hover:text-white rounded-xl transition-all flex items-center justify-center cursor-pointer">
                                                <i className="fa-solid fa-trash-can text-xs"></i>
                                            </button>
                                        </div>
                                    ))}
                                </div>
                            </div>
                        ) : (
                            <div className="space-y-6">
                                <div className="flex items-center justify-between px-1">
                                    <h2 className="font-black text-slate-900">Game Stalls</h2>
                                    <button onClick={() => { setEditingGame(null); setStallForm({ name: '', image: '', type: GameType.UID, description: '' }); setShowGameForm(true); }} className="bg-indigo-600 text-white px-4 py-2 rounded-xl text-[10px] font-black uppercase tracking-widest shadow-lg shadow-indigo-100">Create Stall</button>
                                </div>

                                {showGameForm && (
                                    <div className="bg-white p-6 rounded-3xl border border-slate-100 shadow-xl space-y-4 animate-in zoom-in-95">
                                        <h3 className="text-sm font-black text-indigo-600 uppercase tracking-widest">{editingGame ? 'Edit Stall Profile' : 'Setup New Stall'}</h3>
                                        <div className="space-y-3">
                                            <label className="text-[10px] font-black text-slate-400 uppercase tracking-widest px-2">Game Name</label>
                                            <input type="text" placeholder="e.g. Free Fire" value={stallForm.name} onChange={e => setStallForm({...stallForm, name: e.target.value})} className="w-full bg-slate-50 border p-4 rounded-2xl text-sm font-bold outline-none" />
                                            <label className="text-[10px] font-black text-slate-400 uppercase tracking-widest px-2">Logo URL</label>
                                            <input type="text" placeholder="https://..." value={stallForm.image} onChange={e => setStallForm({...stallForm, image: e.target.value})} className="w-full bg-slate-50 border p-4 rounded-2xl text-sm font-bold outline-none" />
                                            <label className="text-[10px] font-black text-slate-400 uppercase tracking-widest px-2">Top-Up Method</label>
                                            <select value={stallForm.type} onChange={e => setStallForm({...stallForm, type: e.target.value as any})} className="w-full bg-slate-50 border p-4 rounded-2xl text-sm font-bold outline-none">
                                                <option value={GameType.UID}>Uid Top Up</option>
                                                <option value={GameType.VOUCHER}>Unipin Voucher</option>
                                            </select>
                                            <label className="text-[10px] font-black text-slate-400 uppercase tracking-widest px-2">Description / Instructions</label>
                                            <textarea placeholder="Write stall rules here..." value={stallForm.description} onChange={e => setStallForm({...stallForm, description: e.target.value})} className="w-full bg-slate-50 border p-4 rounded-2xl text-sm font-bold h-24 outline-none" />
                                        </div>
                                        <div className="flex flex-col gap-2 pt-4">
                                            <button onClick={handleSaveStall} className="w-full bg-slate-900 text-white py-4 rounded-2xl font-black text-xs uppercase shadow-xl active:scale-95 transition-all">
                                                {editingGame ? 'Save Changes' : 'Publish Stall'}
                                            </button>
                                            <button onClick={() => { setShowGameForm(false); setEditingGame(null); }} className="w-full py-4 text-slate-400 font-black text-xs uppercase">Discard</button>
                                            {editingGame && (
                                                <button onClick={() => handleDeleteGame(editingGame.id)} className="w-full py-4 text-red-600 bg-red-50 border border-red-100 rounded-2xl font-black text-xs uppercase mt-4 hover:bg-red-600 hover:text-white transition-all cursor-pointer">
                                                    <i className="fa-solid fa-trash-can mr-2"></i> Delete Stall & Products
                                                </button>
                                            )}
                                        </div>
                                    </div>
                                )}

                                <div className="grid grid-cols-2 gap-4">
                                    {games.map(game => (
                                        <div key={game.id} className="bg-white p-4 rounded-3xl border border-slate-100 shadow-sm space-y-3 group cursor-pointer hover:border-indigo-200 transition-all active:scale-[0.98] relative">
                                            <div onClick={() => openGameProducts(game)} className="aspect-square rounded-2xl overflow-hidden border bg-slate-50">
                                                <img src={game.image} className="w-full h-full object-cover group-hover:scale-110 transition-transform duration-500" />
                                            </div>
                                            <div onClick={() => openGameProducts(game)}>
                                                <h3 className="text-xs font-black text-slate-900 line-clamp-1">{game.name}</h3>
                                                <p className="text-[8px] font-bold text-slate-400 uppercase">{game.type}</p>
                                            </div>
                                            <div className="flex gap-2">
                                                <button onClick={() => openGameProducts(game)} className="flex-1 bg-indigo-50 text-indigo-600 py-2 rounded-xl text-[8px] font-black uppercase hover:bg-indigo-600 hover:text-white transition-colors">Manage</button>
                                                <button 
                                                    onClick={(e) => { e.stopPropagation(); setEditingGame(game); setStallForm({ name: game.name, image: game.image, type: game.type, description: game.description }); setShowGameForm(true); }} 
                                                    className="w-10 h-10 bg-slate-50 text-slate-400 hover:bg-indigo-500 hover:text-white rounded-xl transition-all flex items-center justify-center cursor-pointer"
                                                >
                                                    <i className="fa-solid fa-pencil text-[10px]"></i>
                                                </button>
                                                <button 
                                                    onClick={(e) => { e.stopPropagation(); handleDeleteGame(game.id); }} 
                                                    className="w-10 h-10 bg-red-50 text-red-300 hover:bg-red-500 hover:text-white rounded-xl transition-all flex items-center justify-center cursor-pointer"
                                                >
                                                    <i className="fa-solid fa-trash-can text-[10px]"></i>
                                                </button>
                                            </div>
                                        </div>
                                    ))}
                                    {games.length === 0 && (
                                        <div className="col-span-2 py-10 text-center space-y-2">
                                            <p className="text-slate-400 font-bold text-xs uppercase">No active stalls found</p>
                                        </div>
                                    )}
                                </div>
                            </div>
                        )}
                    </div>
                )}

                {activeTab === 'orders' && (
                    <div className="space-y-4 slide-up pb-20">
                        <div className="flex flex-col gap-4">
                            <h2 className="font-black text-slate-900 px-1">Order Stream</h2>
                            <input type="text" placeholder="Search ID, TrxID, Player ID..." value={orderSearch} onChange={e => setOrderSearch(e.target.value)} className="w-full bg-white border border-slate-200 rounded-2xl px-6 py-4 text-sm font-bold shadow-sm outline-none" />
                        </div>
                        {orders.filter(o => o.id.toLowerCase().includes(orderSearch.toLowerCase()) || o.trxId?.toLowerCase().includes(orderSearch.toLowerCase()) || o.playerUid?.includes(orderSearch)).map(order => (
                            <div key={order.id} className="bg-white p-5 rounded-3xl border border-slate-100 shadow-sm space-y-4">
                                <div className="flex justify-between items-start">
                                    <div>
                                        <h3 className="font-black text-slate-900">#{order.id}</h3>
                                        <p className="text-[10px] text-slate-400 font-bold uppercase">{order.userName} • {order.gameName}</p>
                                    </div>
                                    <span className={`text-[10px] font-black px-3 py-1 rounded-full uppercase ${order.status === OrderStatus.COMPLETED ? 'bg-green-100 text-green-700' : order.status === OrderStatus.CANCELLED ? 'bg-red-100 text-red-700' : 'bg-orange-100 text-orange-700'}`}>
                                        {order.status}
                                    </span>
                                </div>
                                <div className="grid grid-cols-2 gap-4 text-xs">
                                    <div><p className="text-[8px] text-slate-400 font-bold uppercase">Product</p><p className="font-black">{order.productName}</p></div>
                                    <div><p className="text-[8px] text-slate-400 font-bold uppercase">Price</p><p className="font-black text-emerald-600">৳{order.price}</p></div>
                                    <div><p className="text-[8px] text-slate-400 font-bold uppercase">Player ID</p><p className="font-black">{order.playerUid || 'N/A'}</p></div>
                                    <div><p className="text-[8px] text-slate-400 font-bold uppercase">TrxID</p><p className="font-black truncate">{order.trxId || 'WALLET'}</p></div>
                                </div>
                                <div className="flex gap-2 pt-2">
                                    <button onClick={() => handleUpdateStatus(order.id, OrderStatus.PROCESSING)} className="flex-1 bg-orange-500 text-white py-2 rounded-xl text-[10px] font-black uppercase shadow-lg shadow-orange-100 active:scale-95 transition-all">Process</button>
                                    <button onClick={() => handleUpdateStatus(order.id, OrderStatus.COMPLETED)} className="flex-1 bg-green-600 text-white py-2 rounded-xl text-[10px] font-black uppercase shadow-lg shadow-green-100 active:scale-95 transition-all">Complete</button>
                                    <button onClick={() => handleUpdateStatus(order.id, OrderStatus.CANCELLED)} className="flex-1 bg-red-600 text-white py-2 rounded-xl text-[10px] font-black uppercase shadow-lg shadow-red-100 active:scale-95 transition-all">Cancel</button>
                                </div>
                            </div>
                        ))}
                    </div>
                )}

                {activeTab === 'notice' && settings && (
                    <div className="space-y-6 slide-up">
                        <h2 className="font-black text-slate-900 px-1">Alert Marquee</h2>
                        <div className="bg-white p-6 rounded-[2.5rem] border border-slate-100 shadow-xl space-y-6">
                            <div className="flex items-center justify-between p-4 bg-slate-50 rounded-2xl">
                                <span className="font-black text-xs uppercase tracking-widest text-slate-600">Active Status</span>
                                <input type="checkbox" checked={settings.marqueeStatus} onChange={() => setSettings({...settings, marqueeStatus: !settings.marqueeStatus})} className="w-6 h-6 accent-amber-500" />
                            </div>
                            <div className="space-y-2">
                                <label className="text-[10px] font-black text-slate-400 uppercase tracking-widest px-2">Notice Message</label>
                                <textarea value={settings.marqueeText} onChange={e => setSettings({...settings, marqueeText: e.target.value})} className="w-full bg-slate-50 border rounded-2xl p-4 text-sm font-bold min-h-[120px] outline-none focus:ring-2 focus:ring-amber-500" />
                            </div>
                            <button onClick={async () => { await dbService.updateSettings(settings); showToast('Notice updated!', 'success'); }} className="w-full bg-amber-500 text-white py-5 rounded-2xl font-black text-sm uppercase shadow-lg shadow-amber-100">Save Notice</button>
                        </div>
                    </div>
                )}

                {activeTab === 'settings' && settings && (
                    <div className="space-y-6 slide-up pb-10">
                        <h2 className="font-black text-slate-900 px-1">System Config</h2>
                        <div className="bg-white p-6 rounded-[2.5rem] border border-slate-100 shadow-xl space-y-5">
                            <label className="text-[10px] font-black text-slate-400 uppercase px-2">Brand Name</label>
                            <input type="text" placeholder="Site Name" value={settings.siteName} onChange={e => setSettings({...settings, siteName: e.target.value})} className="w-full bg-slate-50 border p-4 rounded-2xl text-sm font-bold outline-none" />
                            <label className="text-[10px] font-black text-slate-400 uppercase px-2">Currency Symbol</label>
                            <input type="text" placeholder="Currency" value={settings.currencySymbol} onChange={e => setSettings({...settings, currencySymbol: e.target.value})} className="w-full bg-slate-50 border p-4 rounded-2xl text-sm font-bold outline-none" />
                            <label className="text-[10px] font-black text-slate-400 uppercase px-2">WhatsApp Link</label>
                            <input type="text" placeholder="WhatsApp" value={settings.fabLink} onChange={e => setSettings({...settings, fabLink: e.target.value})} className="w-full bg-slate-50 border p-4 rounded-2xl text-sm font-bold outline-none" />
                            <button onClick={async () => { await dbService.updateSettings(settings); showToast('Settings saved!', 'success'); }} className="w-full bg-slate-900 text-white py-5 rounded-2xl font-black text-sm uppercase shadow-xl">Apply Changes</button>
                        </div>
                    </div>
                )}
            </div>
        </div>
    );
};

export default AdminDashboard;
