
import React, { useState } from 'react';
import { dbService } from '../services/db';
import { PaymentMethod, OrderStatus } from '../types';

interface Props {
    orderData: any;
    userId: string;
    onNavigate: (page: string, data?: any) => void;
    showToast: (message: string, type?: 'success' | 'error' | 'info') => void;
}

const InstantPay: React.FC<Props> = ({ orderData, userId, onNavigate, showToast }) => {
    const methods = dbService.getPaymentMethods();
    const [selectedMethod, setSelectedMethod] = useState<PaymentMethod | null>(null);
    const [senderNumber, setSenderNumber] = useState('');
    const [trxId, setTrxId] = useState('');
    const [isSubmitting, setIsSubmitting] = useState(false);

    const handleSubmit = async () => {
        if (!selectedMethod) return showToast('Please select a payment method', 'error');
        if (!senderNumber) return showToast(`Please enter your ${selectedMethod.name} number`, 'error');
        if (!trxId) return showToast('Please enter your Transaction ID (TrxID)', 'error');
        
        setIsSubmitting(true);
        try {
            await dbService.createOrder({
                userId,
                userName: 'User',
                gameName: orderData.game.name,
                productName: orderData.product.name,
                price: orderData.totalPrice,
                quantity: orderData.quantity,
                playerUid: orderData.playerUid,
                paymentMethod: selectedMethod.name,
                trxId: trxId,
                status: OrderStatus.PENDING
            });
            showToast('Order submitted! Please wait for manual verification.', 'success');
            onNavigate('orders');
        } catch (error) {
            showToast('Failed to submit order. Please check your connection.', 'error');
        } finally {
            setIsSubmitting(false);
        }
    };

    return (
        <div className="p-4 space-y-6 slide-up pb-32">
            <div className="bg-slate-900 text-white p-6 rounded-3xl space-y-4 text-center shadow-xl">
                <p className="text-slate-400 text-xs font-bold uppercase tracking-widest">Total Payment</p>
                <h1 className="text-4xl font-black">৳{orderData?.totalPrice?.toFixed(2) || '0.00'}</h1>
                <div className="flex items-center justify-center gap-2 text-xs text-red-400 font-bold bg-red-500/10 py-1 px-4 rounded-full w-max mx-auto">
                    <i className="fa-solid fa-lock text-[10px]"></i>
                    Secure Transaction
                </div>
            </div>

            <section className="space-y-4">
                <h2 className="font-bold text-slate-900 px-1">Choose Payment Method</h2>
                <div className="grid grid-cols-2 gap-3">
                    {methods.map(m => (
                        <button 
                            key={m.id}
                            onClick={() => setSelectedMethod(m)}
                            className={`p-4 rounded-2xl border-2 transition-all flex flex-col items-center gap-2 ${selectedMethod?.id === m.id ? 'border-red-600 bg-red-50 ring-4 ring-red-100/50' : 'border-slate-100 hover:border-slate-200'}`}
                        >
                            <div className="w-12 h-12 bg-white rounded-xl shadow-sm flex items-center justify-center border p-2">
                                <span className="font-black text-[10px] text-slate-800 uppercase">{m.name}</span>
                            </div>
                            <span className="text-xs font-bold">{m.name}</span>
                        </button>
                    ))}
                </div>
            </section>

            {selectedMethod && (
                <section className="space-y-6 bg-slate-50 p-6 rounded-3xl border border-slate-100 shadow-sm">
                    <div className="space-y-4 text-center">
                        <div className="relative inline-block">
                             <img src={selectedMethod.qrImage} className="w-44 h-44 mx-auto rounded-3xl shadow-xl border-4 border-white" alt="QR Code" />
                             <div className="absolute -bottom-2 -right-2 bg-red-600 text-white px-3 py-1 rounded-full text-[8px] font-black uppercase shadow-lg">Scan to Pay</div>
                        </div>
                        <div className="space-y-1">
                            <p className="text-[10px] text-slate-400 font-bold uppercase tracking-widest">Send money to this number:</p>
                            <div className="flex items-center justify-center gap-3 bg-white p-3 rounded-2xl border border-slate-200 shadow-sm w-full">
                                <span className="text-xl font-black text-slate-900 tracking-tight">{selectedMethod.number}</span>
                                <button onClick={() => {
                                    navigator.clipboard.writeText(selectedMethod.number);
                                    showToast('Number copied to clipboard!', 'success');
                                }} className="bg-red-600 text-white w-9 h-9 rounded-xl flex items-center justify-center active:scale-90 transition-all shadow-md">
                                    <i className="fa-solid fa-copy"></i>
                                </button>
                            </div>
                        </div>
                        <div className="bg-white/60 p-3 rounded-xl border border-slate-200/50 text-[10px] text-slate-500 font-medium leading-relaxed text-left flex gap-3 items-start">
                            <i className="fa-solid fa-info-circle text-red-600 mt-0.5"></i>
                            <span>{selectedMethod.description}</span>
                        </div>
                    </div>

                    <div className="space-y-4">
                        <div className="space-y-1.5">
                            <label className="text-[10px] font-bold text-slate-400 uppercase tracking-widest px-2">Your {selectedMethod.name} Number</label>
                            <div className="relative">
                                <i className="fa-solid fa-phone absolute left-4 top-1/2 -translate-y-1/2 text-slate-300"></i>
                                <input 
                                    type="text"
                                    inputMode="numeric"
                                    value={senderNumber}
                                    onChange={e => setSenderNumber(e.target.value.replace(/\D/g, ''))}
                                    className="w-full bg-white border border-slate-200 rounded-2xl pl-12 pr-4 py-4 text-sm font-bold focus:ring-4 focus:ring-red-100 outline-none transition-all"
                                    placeholder="01XXX-XXXXXX"
                                />
                            </div>
                        </div>
                        <div className="space-y-1.5">
                            <label className="text-[10px] font-bold text-slate-400 uppercase tracking-widest px-2">Transaction ID (TrxID)</label>
                            <div className="relative">
                                <i className="fa-solid fa-receipt absolute left-4 top-1/2 -translate-y-1/2 text-slate-300"></i>
                                <input 
                                    type="text"
                                    value={trxId}
                                    onChange={e => setTrxId(e.target.value)}
                                    className="w-full bg-white border border-slate-200 rounded-2xl pl-12 pr-4 py-4 text-sm font-bold focus:ring-4 focus:ring-red-100 outline-none transition-all"
                                    placeholder="Enter TrxID"
                                />
                            </div>
                        </div>
                    </div>

                    <button 
                        onClick={handleSubmit}
                        disabled={isSubmitting}
                        className="w-full bg-slate-900 text-white py-5 rounded-[1.5rem] font-black text-lg shadow-xl shadow-slate-200 hover:bg-black active:scale-[0.98] transition-all flex items-center justify-center gap-3 disabled:opacity-70"
                    >
                        {isSubmitting ? (
                            <>
                                <i className="fa-solid fa-circle-notch fa-spin"></i>
                                Verifying...
                            </>
                        ) : (
                            'Confirm Payment'
                        )}
                    </button>
                </section>
            )}
        </div>
    );
};

export default InstantPay;
