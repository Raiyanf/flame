
import React from 'react';
import { User } from '../types';

interface Props {
    user: User | null;
    onLogout: () => void;
    onUpdateUser: (u: any) => void;
    onNavigate: (page: string, data?: any) => void;
    showToast: (message: string, type?: 'success' | 'error' | 'info') => void;
}

const Profile: React.FC<Props> = ({ user, onLogout, onNavigate, showToast }) => {
    // Safety check for loading/null state
    if (!user) {
        return (
            <div className="flex flex-col items-center justify-center py-20 gap-4">
                <i className="fa-solid fa-circle-notch fa-spin text-red-600 text-2xl"></i>
                <p className="text-xs font-bold text-slate-400 animate-pulse uppercase tracking-widest">Loading Account...</p>
            </div>
        );
    }

    // Stats reordered as requested: Spent (Green), Order (Red), Pin (Blue)
    const stats = [
        { label: 'Total Spent', value: `৳${(user.spend || 0).toFixed(2)}`, icon: 'fa-coins', color: 'bg-green-50 text-green-600' },
        { label: 'Total Order', value: user.order || 0, icon: 'fa-box', color: 'bg-red-50 text-red-600' },
        { label: 'Support Pin', value: user.supportPin || '----', icon: 'fa-key', color: 'bg-blue-50 text-blue-600' }
    ];

    return (
        <div className="p-4 space-y-6 slide-up pb-24">
            {/* Header / Avatar Section */}
            <div className="flex flex-col items-center py-6 gap-4">
                <div className="relative">
                    <div className={`w-24 h-24 rounded-full bg-slate-900 border-4 ${user.ban ? 'border-red-600' : 'border-green-500'} flex items-center justify-center text-white text-3xl font-black shadow-2xl`}>
                        {(user.username || 'U').charAt(0).toUpperCase()}
                    </div>
                    <div className={`absolute bottom-0 right-0 w-8 h-8 ${user.ban ? 'bg-red-500' : 'bg-green-500'} border-4 border-white rounded-full`}></div>
                </div>
                <div className="text-center">
                    {/* Visual Hierarchy: Username below the picture, then Mobile Number below that */}
                    <h1 className="text-xl font-black text-slate-900 leading-tight">@{user.username}</h1>
                    <p className="text-sm font-bold text-slate-500 mt-1">{user.phone}</p>
                    <div className="mt-3 bg-red-50 px-4 py-1.5 rounded-full border border-red-100 inline-block">
                         <p className="text-sm font-black text-red-600">Wallet: ৳{(user.balance || 0).toFixed(2)}</p>
                    </div>
                    {user.ban === true && (
                        <div className="mt-2 bg-red-600 text-white px-3 py-1 rounded-full text-[10px] font-black uppercase">Account Banned</div>
                    )}
                </div>
            </div>

            {/* Statistics Stack - Spent, Order, Pin */}
            <div className="space-y-3">
                {stats.map(s => (
                    <div 
                        key={s.label} 
                        className="bg-white p-4 rounded-2xl border border-slate-100 shadow-sm flex items-center justify-between gap-4 group hover:border-slate-200 transition-all"
                    >
                        <div className="flex items-center gap-4">
                            <div className={`w-12 h-12 rounded-xl flex items-center justify-center text-xl shadow-sm ${s.color}`}>
                                <i className={`fa-solid ${s.icon}`}></i>
                            </div>
                            <div>
                                <p className="text-[10px] font-bold text-slate-400 uppercase tracking-widest">{s.label}</p>
                                <p className="text-lg font-black text-slate-900">{s.value}</p>
                            </div>
                        </div>
                        <div className="w-8 h-8 rounded-full bg-slate-50 flex items-center justify-center text-slate-300">
                            <i className="fa-solid fa-chevron-right text-[10px]"></i>
                        </div>
                    </div>
                ))}
            </div>

            {/* Admin Panel Link */}
            {user.isAdmin && (
                <div className="pt-2">
                    <button 
                        onClick={() => onNavigate('admin')}
                        className="w-full flex items-center justify-between p-5 bg-slate-900 text-white rounded-[2rem] shadow-xl shadow-slate-200 border border-slate-800 active:scale-[0.98] transition-all group"
                    >
                        <div className="flex items-center gap-4">
                            <div className="w-10 h-10 bg-red-600 rounded-2xl flex items-center justify-center shadow-lg group-hover:rotate-12 transition-transform">
                                <i className="fa-solid fa-shield-halved text-white text-sm"></i>
                            </div>
                            <div className="text-left">
                                <p className="text-xs font-black uppercase tracking-widest text-red-500">Authorized Admin</p>
                                <p className="text-sm font-bold">Open Management Panel</p>
                            </div>
                        </div>
                        <i className="fa-solid fa-arrow-right-long text-slate-500"></i>
                    </button>
                </div>
            )}

            {/* Account Details Section */}
            <section className="bg-white rounded-3xl border border-slate-100 overflow-hidden shadow-sm">
                <div className="p-4 border-b border-slate-50 flex items-center justify-between">
                    <h2 className="font-black text-slate-900 flex items-center gap-2">
                        <i className="fa-solid fa-address-card text-red-600"></i>
                        Account Details
                    </h2>
                </div>
                <div className="p-4 space-y-3">
                    {/* Final Ordering: Username ID, Email, Mobile Number */}
                    {[
                        { label: 'Username ID', value: user.username, icon: 'fa-at' },
                        { label: 'Email Address', value: user.email, icon: 'fa-envelope' },
                        { label: 'Mobile Number', value: user.phone || 'Not provided', icon: 'fa-phone' }
                    ].map(item => (
                        <div key={item.label} className="flex items-center gap-4 bg-slate-50 p-3 rounded-xl border border-slate-100">
                            <div className="w-8 h-8 rounded-lg bg-white flex items-center justify-center text-slate-400 border border-slate-100">
                                <i className={`fa-solid ${item.icon} text-xs`}></i>
                            </div>
                            <div className="min-w-0 flex-1">
                                <p className="text-[8px] font-black text-slate-400 uppercase">{item.label}</p>
                                <p className="text-sm font-bold text-slate-700 truncate">{item.value}</p>
                            </div>
                        </div>
                    ))}
                </div>
            </section>

            {/* Actions */}
            <div className="space-y-3">
                <button 
                    onClick={() => onNavigate('orders')}
                    className="w-full flex items-center justify-between p-4 bg-white rounded-2xl border border-slate-100 shadow-sm font-bold text-slate-700 hover:bg-slate-50 transition-all"
                >
                    <div className="flex items-center gap-3">
                        <i className="fa-solid fa-clock-rotate-left text-red-600"></i>
                        Order History
                    </div>
                    <i className="fa-solid fa-chevron-right text-slate-300"></i>
                </button>
                <button 
                    onClick={() => onNavigate('my_codes')}
                    className="w-full flex items-center justify-between p-4 bg-white rounded-2xl border border-slate-100 shadow-sm font-bold text-slate-700 hover:bg-slate-50 transition-all"
                >
                    <div className="flex items-center gap-3">
                        <i className="fa-solid fa-ticket text-orange-500"></i>
                        Voucher Codes
                    </div>
                    <i className="fa-solid fa-chevron-right text-slate-300"></i>
                </button>
            </div>

            {/* Logout */}
            <div className="pt-4">
                <button 
                    onClick={onLogout}
                    className="w-full bg-slate-900 text-white py-5 rounded-3xl font-black text-lg shadow-xl shadow-slate-200 hover:bg-black active:scale-[0.98] transition-all flex items-center justify-center gap-3 border border-white/10"
                >
                    <i className="fa-solid fa-right-from-bracket"></i>
                    Logout Account
                </button>
            </div>
        </div>
    );
};

export default Profile;
